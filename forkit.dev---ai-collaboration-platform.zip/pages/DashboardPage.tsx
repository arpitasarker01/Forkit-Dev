
import React, { useState, useMemo } from 'react';
import ModelCard from '../components/ModelCard';
import { AIModel, Page, NotificationType } from '../types';
import Modal from '../components/Modal';

interface DashboardPageProps {
  navigateTo: (page: Page, modelId?: string) => void;
  addToast: (message: string, type: NotificationType) => void;
  models: AIModel[];
  addModel: (model: AIModel) => void;
}

const DashboardPage: React.FC<DashboardPageProps> = ({ navigateTo, addToast, models, addModel }) => {
  const [activeTab, setActiveTab] = useState('Verified');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState('Most Voted');

  const [isForkModalOpen, setIsForkModalOpen] = useState(false);
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState<AIModel | null>(null);

  const filteredModels = useMemo(() => {
    let currentModels: AIModel[] = [...models];

    // 1. Filter by tab
    if (activeTab === 'Verified') {
      currentModels = currentModels.filter(m => m.status === 'Verified');
    } else if (activeTab === 'Your Models') {
      // Placeholder: show models by a specific author. In a real app this would be the logged-in user.
      currentModels = currentModels.filter(m => m.author === 'SynthAI Labs'); 
    }

    // 2. Filter by search term
    if (searchTerm.trim()) {
      const lowercasedFilter = searchTerm.toLowerCase();
      currentModels = currentModels.filter(m => 
        m.name.toLowerCase().includes(lowercasedFilter) ||
        m.provenanceHash.toLowerCase().includes(lowercasedFilter) ||
        m.task.toLowerCase().includes(lowercasedFilter) ||
        m.dataset.toLowerCase().includes(lowercasedFilter) ||
        m.modelType.toLowerCase().includes(lowercasedFilter)
      );
    }
    
    // 3. Sort
    switch(sortOrder) {
      case 'Most Voted':
        currentModels.sort((a, b) => b.votes - a.votes);
        break;
      case 'Most Downloaded':
        currentModels.sort((a, b) => b.downloads - a.downloads);
        break;
      case 'Newest':
        currentModels.sort((a, b) => parseInt(b.id) - parseInt(a.id));
        break;
    }

    return currentModels;
  }, [activeTab, searchTerm, sortOrder, models]);
  
  const handleForkClick = (model: AIModel) => {
    setSelectedModel(model);
    setIsForkModalOpen(true);
  };
  
  const handleUpgradeClick = (modelName: string) => {
    setSelectedModel({name: modelName} as AIModel); // Just need name for the modal
    setIsUpgradeModalOpen(true);
  };

  const confirmFork = () => {
    if (!selectedModel) return;
    const newFork: AIModel = {
        ...selectedModel,
        id: Date.now().toString(),
        name: `${selectedModel.name} Fork`,
        author: 'Jane Doe', // Logged in user
        votes: 0,
        forks: 0,
        downloads: 0,
        status: 'Verified'
    };
    addModel(newFork);
    addToast(`Successfully forked '${selectedModel.name}'!`, 'success');
    setIsForkModalOpen(false);
    navigateTo('modelDetails', newFork.id);
  };


  const TABS = ['Verified', 'Pending Approval', 'Your Models'];

  return (
    <div className="container mx-auto">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-light-text-primary dark:text-dark-text-primary">Explore Models</h2>
        <p className="text-light-text-secondary dark:text-dark-text-secondary mt-2">Discover, fork, and collaborate on the latest AI models from the community.</p>
      </div>

      {/* Tabs */}
      <div className="mb-6 border-b border-light-border dark:border-dark-border">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          {TABS.map(tab => (
            <button
              key={tab}
              onClick={() => {
                if (tab === 'Pending Approval') {
                    navigateTo('pendingApproval');
                } else {
                    setActiveTab(tab);
                }
              }}
              className={`${
                activeTab === tab
                  ? 'border-light-accent-primary dark:border-dark-accent-primary text-light-accent-primary dark:text-dark-accent-primary'
                  : 'border-transparent text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary hover:border-light-text-secondary dark:hover:border-dark-text-secondary'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors`}
            >
              {tab}
            </button>
          ))}
        </nav>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col md:flex-row gap-4 mb-8">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <svg className="w-5 h-5 text-light-text-secondary dark:text-dark-text-secondary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-sm text-light-text-primary dark:text-dark-text-primary bg-light-bg-secondary dark:bg-dark-bg-secondary border border-light-border dark:border-dark-border rounded-lg focus:ring-light-accent-primary dark:focus:ring-dark-accent-primary focus:border-light-accent-primary dark:focus:border-dark-accent-primary"
            placeholder="Search by name, hash, task..."
          />
        </div>
        <div className="flex gap-4">
          <select 
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value)}
            className="bg-light-bg-secondary dark:bg-dark-bg-secondary border border-light-border dark:border-dark-border rounded-lg text-sm text-light-text-primary dark:text-dark-text-primary focus:ring-light-accent-primary dark:focus:ring-dark-accent-primary focus:border-light-accent-primary dark:focus:border-dark-accent-primary px-3 py-2">
            <option>Most Voted</option>
            <option>Most Downloaded</option>
            <option>Newest</option>
          </select>
        </div>
      </div>

      {/* Models Grid */}
      {filteredModels.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6">
          {filteredModels.map(model => (
            <ModelCard key={model.id} model={model} navigateTo={navigateTo} onFork={handleForkClick} onUpgrade={handleUpgradeClick} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center text-center border-2 border-dashed border-light-border dark:border-dark-border rounded-lg py-24">
            <h3 className="mt-2 text-xl font-semibold text-light-text-primary dark:text-dark-text-primary">No models found</h3>
            <p className="mt-1 text-sm text-light-text-secondary dark:text-dark-text-secondary">Try adjusting your search or filter criteria.</p>
        </div>
      )}

      {/* Fork Modal */}
      <Modal isOpen={isForkModalOpen} onClose={() => setIsForkModalOpen(false)} title={`Fork '${selectedModel?.name}'`}>
          <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
              You are about to create a new fork of this model. This will create a new, linked version in your profile that you can modify.
          </p>
          <div className="flex justify-end gap-3">
              <button onClick={() => setIsForkModalOpen(false)} className="bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-4 rounded-lg text-sm">Cancel</button>
              <button onClick={confirmFork} className="bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-4 rounded-lg text-sm">Confirm Fork</button>
          </div>
      </Modal>

      {/* Upgrade Modal */}
      <Modal isOpen={isUpgradeModalOpen} onClose={() => setIsUpgradeModalOpen(false)} title="Upgrade Required">
          <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
              The model <span className="font-bold text-light-text-primary dark:text-dark-text-primary">{selectedModel?.name}</span> is only available to users on a Pro plan or higher.
          </p>
          <div className="flex justify-end gap-3">
              <button onClick={() => setIsUpgradeModalOpen(false)} className="bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-4 rounded-lg text-sm">Maybe Later</button>
              <button onClick={() => navigateTo('pricing')} className="bg-light-accent-secondary hover:bg-light-accent-secondary-hover dark:bg-dark-accent-secondary dark:hover:bg-dark-accent-secondary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-4 rounded-lg text-sm">View Plans</button>
          </div>
      </Modal>
    </div>
  );
};

export default DashboardPage;
