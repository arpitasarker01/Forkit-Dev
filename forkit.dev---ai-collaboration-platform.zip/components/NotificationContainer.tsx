import React from 'react';
import { Notification } from '../types';
import NotificationToast from './NotificationToast';

interface NotificationContainerProps {
  toasts: Notification[];
  removeToast: (id: string) => void;
}

const NotificationContainer: React.FC<NotificationContainerProps> = ({ toasts, removeToast }) => {
  return (
    <div className="fixed top-5 right-5 z-50 w-full max-w-xs space-y-3">
      {toasts.map(toast => (
        <NotificationToast
          key={toast.id}
          notification={toast}
          onDismiss={() => removeToast(toast.id)}
        />
      ))}
    </div>
  );
};

export default NotificationContainer;
