
import React, { useState, useMemo } from 'react';
import { NotificationType, WorkspaceMember } from '../types';
import { WORKSPACE_MEMBERS_DATA, USER_QUOTAS_DATA, MODELS_DATA } from '../constants';
import Modal from '../components/Modal';
import QuotaMeter from '../components/QuotaMeter';
import ModelCard from '../components/ModelCard';

interface WorkspacePageProps {
  addToast: (message: string, type: NotificationType) => void;
}

const WorkspacePage: React.FC<WorkspacePageProps> = ({ addToast }) => {
  const [members, setMembers] = useState<WorkspaceMember[]>(WORKSPACE_MEMBERS_DATA);
  const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
  
  const workspaceModels = useMemo(() => MODELS_DATA.filter(m => m.author === 'SynthAI Labs'), []); // Mock private models

  const handleInvite = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const email = formData.get('email') as string;
    const newMember: WorkspaceMember = {
        name: email.split('@')[0],
        email,
        avatarUrl: `https://picsum.photos/seed/${email}/40/40`,
        role: formData.get('role') as 'Editor',
    };
    setMembers(prev => [...prev, newMember]);
    addToast(`Invitation sent to ${email}`, 'success');
    setIsInviteModalOpen(false);
  };
  
  return (
    <div className="container mx-auto">
        <div className="mb-8">
            <h2 className="text-3xl font-bold text-light-text-primary dark:text-dark-text-primary">SynthAI Labs Workspace</h2>
            <p className="text-light-text-secondary dark:text-dark-text-secondary mt-2">Manage your team, models, and usage.</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
                {/* Members List */}
                <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary border border-light-border dark:border-dark-border rounded-lg p-6">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-semibold text-light-text-primary dark:text-dark-text-primary">Team Members ({members.length})</h3>
                        <button onClick={() => setIsInviteModalOpen(true)} className="bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-4 rounded-lg text-sm">Invite Member</button>
                    </div>
                    <ul className="space-y-3">
                        {members.map(member => (
                            <li key={member.email} className="flex items-center justify-between p-2 rounded-md hover:bg-light-bg dark:hover:bg-dark-bg">
                                <div className="flex items-center gap-3">
                                    <img src={member.avatarUrl} alt={member.name} className="w-8 h-8 rounded-full" />
                                    <div>
                                        <p className="font-medium text-sm text-light-text-primary dark:text-dark-text-primary">{member.name}</p>
                                        <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary">{member.email}</p>
                                    </div>
                                </div>
                                <span className="text-xs font-medium text-light-text-secondary dark:text-dark-text-secondary bg-light-bg dark:bg-dark-bg px-2 py-1 rounded-full border border-light-border dark:border-dark-border">{member.role}</span>
                            </li>
                        ))}
                    </ul>
                </div>
                {/* Private Models */}
                <div>
                     <h3 className="text-lg font-semibold text-light-text-primary dark:text-dark-text-primary mb-4">Workspace Models</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {workspaceModels.map(model => (
                            <ModelCard key={model.id} model={model} navigateTo={() => {}} onFork={() => {}} onUpgrade={() => {}} />
                        ))}
                     </div>
                </div>
            </div>
            
            {/* Right Sidebar */}
            <div className="space-y-8">
                {/* Enterprise Features */}
                 <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary border border-dashed border-light-accent-secondary dark:border-dark-accent-secondary rounded-lg p-6 text-center">
                     <h3 className="text-lg font-semibold text-light-text-primary dark:text-dark-text-primary">Enterprise Features</h3>
                     <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mt-2">Upgrade to Enterprise to unlock custom governance rules and full audit logs.</p>
                     <button className="mt-4 bg-light-accent-secondary hover:bg-light-accent-secondary-hover dark:bg-dark-accent-secondary dark:hover:bg-dark-accent-secondary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-4 rounded-lg text-sm">Learn More</button>
                 </div>
            </div>
        </div>

        {/* Invite Modal */}
        <Modal isOpen={isInviteModalOpen} onClose={() => setIsInviteModalOpen(false)} title="Invite New Member">
            <form onSubmit={handleInvite}>
                <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">Enter the email and assign a role for the new team member.</p>
                <div className="space-y-4">
                     <input name="email" type="email" required placeholder="Email address" className="w-full bg-light-bg dark:bg-dark-bg border border-light-border dark:border-dark-border rounded-md text-sm p-2" />
                     <select name="role" defaultValue="Editor" className="w-full bg-light-bg dark:bg-dark-bg border border-light-border dark:border-dark-border rounded-md text-sm p-2">
                         <option>Editor</option>
                         <option>Viewer</option>
                     </select>
                </div>
                <div className="flex justify-end gap-3 mt-6">
                    <button type="button" onClick={() => setIsInviteModalOpen(false)} className="bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-4 rounded-lg text-sm">Cancel</button>
                    <button type="submit" className="bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-4 rounded-lg text-sm">Send Invite</button>
                </div>
            </form>
        </Modal>
    </div>
  );
};

export default WorkspacePage;
