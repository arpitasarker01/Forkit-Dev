
import React from 'react';
import { AIModel, Page } from '../types';
import { ForkIcon, VoteIcon, DownloadIcon, PlaygroundIcon } from '../constants';

interface ModelCardProps {
  model: AIModel;
  navigateTo: (page: Page, modelId: string, hash?: string) => void;
  onFork: (model: AIModel) => void;
  onUpgrade: (modelName: string) => void;
}

const ModelCard: React.FC<ModelCardProps> = ({ model, navigateTo, onFork, onUpgrade }) => {
  const statusColor = model.status === 'Verified' 
    ? 'bg-light-success/10 text-light-success dark:bg-dark-info/10 dark:text-dark-info' 
    : 'bg-light-warning/10 text-light-warning dark:bg-dark-warning/10 dark:text-dark-warning';
  const statusDotColor = model.status === 'Verified' 
    ? 'bg-light-success dark:bg-dark-info' 
    : 'bg-light-warning dark:bg-dark-warning';

  const handleDownload = () => {
    if (model.plan === 'Pro') {
      onUpgrade(model.name);
    } else {
      // Simulate download for free models
      window.open('about:blank', '_blank');
    }
  }

  return (
    <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary border border-light-border dark:border-dark-border rounded-lg p-5 flex flex-col h-full transition-all duration-300 hover:border-light-accent-primary dark:hover:border-dark-accent-primary hover:shadow-2xl dark:hover:shadow-dark-accent-primary/10 hover:shadow-light-accent-primary/10">
      <div className="flex justify-between items-start mb-3">
        <div>
          <h3 className="font-bold text-lg text-light-text-primary dark:text-dark-text-primary group-hover:text-light-accent-primary dark:group-hover:text-dark-accent-primary transition-colors">{model.name}</h3>
          <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary font-mono break-all">{model.provenanceHash}</p>
        </div>
        <div className={`text-xs font-medium px-2.5 py-1 rounded-full flex items-center ${statusColor}`}>
          <span className={`w-2 h-2 mr-2 rounded-full ${statusDotColor}`}></span>
          {model.status}
        </div>
      </div>
      
      <div className="flex flex-wrap gap-2 mb-4">
        <span className="bg-light-bg dark:bg-dark-bg text-xs font-semibold text-light-text-secondary dark:text-dark-text-secondary px-2 py-1 rounded">Task: {model.task}</span>
        <span className="bg-light-bg dark:bg-dark-bg text-xs font-semibold text-light-text-secondary dark:text-dark-text-secondary px-2 py-1 rounded">Type: {model.modelType}</span>
        <span className="bg-light-bg dark:bg-dark-bg text-xs font-semibold text-light-text-secondary dark:text-dark-text-secondary px-2 py-1 rounded">Dataset: {model.dataset}</span>
      </div>

      <div className="mb-4 flex items-center justify-between text-sm text-light-text-secondary dark:text-dark-text-secondary">
        <div className="flex items-center space-x-4">
            <div className="flex items-center" title="Votes">
                <VoteIcon className="w-4 h-4 mr-1.5" />
                <span>{model.votes.toLocaleString()}</span>
            </div>
            <div className="flex items-center" title="Downloads">
                <DownloadIcon className="w-4 h-4 mr-1.5" />
                <span>{model.downloads.toLocaleString()}</span>
            </div>
            <div className="flex items-center" title="Forks">
                <ForkIcon className="w-4 h-4 mr-1.5" />
                <span>{model.forks.toLocaleString()}</span>
            </div>
        </div>
         {model.plan === 'Pro' && <span className="text-xs font-bold text-light-accent-secondary dark:text-dark-accent-secondary">PRO</span>}
      </div>

      <div className="mt-auto pt-4 border-t border-light-border dark:border-dark-border flex items-center justify-between gap-2">
        <button 
            onClick={() => navigateTo('modelDetails', model.id)}
            className="flex-1 bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-3 rounded-lg text-xs transition-colors duration-200">
            View Details
        </button>
        <div className="flex flex-1 gap-2">
             <button onClick={() => navigateTo('modelDetails', model.id, 'playground')} className="flex-1 bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-3 rounded-lg text-xs transition-colors duration-200 flex justify-center items-center gap-1.5">
                <PlaygroundIcon className="w-3.5 h-3.5" />
                <span>Playground</span>
            </button>
            <button onClick={() => onFork(model)} className="flex-1 bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-3 rounded-lg text-xs transition-colors duration-200">
                Fork
            </button>
        </div>
      </div>
      <button 
          onClick={handleDownload}
          className="w-full mt-2 bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-3 rounded-lg text-xs transition-colors duration-200 flex justify-center items-center gap-1.5">
          <DownloadIcon className="w-3.5 h-3.5" />
          Download
      </button>
    </div>
  );
};

export default ModelCard;
