
import React, { useState } from 'react';
import { API_DOCS_DATA } from '../constants';

const MethodBadge: React.FC<{ method: string }> = ({ method }) => {
    const colorClasses = {
        'GET': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
        'POST': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
    }[method.toUpperCase()] || 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';

    return (
        <span className={`text-xs font-semibold px-2.5 py-1 rounded-md ${colorClasses}`}>{method.toUpperCase()}</span>
    )
}

const DocsPage: React.FC = () => {
    const [activeSection, setActiveSection] = useState('general-information');

    const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
        const sections = ['general-information'].concat(API_DOCS_DATA.sections.map(s => s.title.toLowerCase().replace(/\s+/g, '-')));
        let current = activeSection;
        for (const sectionId of sections) {
            const el = document.getElementById(sectionId);
            if (el && el.getBoundingClientRect().top < 150) {
                current = sectionId;
            }
        }
        setActiveSection(current);
    };

    const navLinkClasses = (id: string) => `block text-sm py-1.5 px-3 rounded-md transition-colors ${
        activeSection === id 
        ? 'bg-light-accent-primary/10 text-light-accent-primary dark:bg-dark-accent-primary/10 dark:text-dark-accent-primary font-semibold' 
        : 'text-light-text-secondary dark:text-dark-text-secondary hover:bg-light-bg-secondary dark:hover:bg-dark-bg-secondary'
    }`;
    
    return (
        <div className="container mx-auto flex gap-12">
            {/* Left Sidebar */}
            <aside className="w-64 flex-shrink-0 hidden lg:block sticky top-24 self-start">
                 <nav className="space-y-1">
                    <a href="#general-information" onClick={() => setActiveSection('general-information')} className={navLinkClasses('general-information')}>General Information</a>
                    <h3 className="pt-4 pb-1 px-3 text-xs font-semibold text-light-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Endpoints</h3>
                    {API_DOCS_DATA.sections.map(section => {
                        const sectionId = section.title.toLowerCase().replace(/\s+/g, '-');
                        return (
                            <a key={section.title} href={`#${sectionId}`} onClick={() => setActiveSection(sectionId)} className={navLinkClasses(sectionId)}>
                                {section.title}
                            </a>
                        )
                    })}
                </nav>
            </aside>
            
            {/* Main Content */}
            <div className="flex-1 min-w-0 max-h-[calc(100vh-10rem)] overflow-y-auto pr-4" onScroll={handleScroll}>
                 <h1 className="text-3xl font-bold text-light-text-primary dark:text-dark-text-primary mb-2">API Documentation</h1>
                 <p className="text-light-text-secondary dark:text-dark-text-secondary mb-12">Welcome to the Forkit.dev API. Find all the information you need to integrate with our platform.</p>

                <section id="general-information" className="mb-12 scroll-mt-24">
                    <h2 className="text-2xl font-semibold border-b border-light-border dark:border-dark-border pb-2 mb-4">General Information</h2>
                    {API_DOCS_DATA.general.map(item => (
                        <p key={item.key} className="text-light-text-secondary dark:text-dark-text-secondary"><span className="font-semibold text-light-text-primary dark:text-dark-text-primary">{item.key}:</span> {item.value}</p>
                    ))}
                </section>
                
                <h2 className="text-2xl font-semibold border-b border-light-border dark:border-dark-border pb-2 mb-4">Endpoints</h2>
                {API_DOCS_DATA.sections.map(section => (
                    <section key={section.title} id={section.title.toLowerCase().replace(/\s+/g, '-')} className="mb-12 scroll-mt-24">
                        <h3 className="text-xl font-semibold mb-6">{section.title}</h3>
                        <div className="space-y-8">
                        {section.endpoints.map(endpoint => (
                            <div key={endpoint.path} className="bg-light-bg-secondary dark:bg-dark-bg-secondary rounded-lg border border-light-border dark:border-dark-border">
                                <div className="p-4 border-b border-light-border dark:border-dark-border">
                                    <div className="flex items-center gap-4">
                                        <MethodBadge method={endpoint.method} />
                                        <p className="font-mono font-semibold text-light-text-primary dark:text-dark-text-primary">{endpoint.path}</p>
                                    </div>
                                    <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mt-2">{endpoint.description}</p>
                                </div>
                                <div className="p-4 text-sm space-y-3">
                                    {endpoint.request && (
                                        <div>
                                            <h5 className="font-semibold text-light-text-primary dark:text-dark-text-primary mb-1">Request ({endpoint.request.type})</h5>
                                            <ul className="list-disc list-inside text-light-text-secondary dark:text-dark-text-secondary font-mono text-xs">
                                                {endpoint.request.params.map(p => <li key={p}>{p}</li>)}
                                            </ul>
                                        </div>
                                    )}
                                    <div>
                                        <h5 className="font-semibold text-light-text-primary dark:text-dark-text-primary mb-1">Response</h5>
                                        <p className="font-mono text-xs text-light-text-secondary dark:text-dark-text-secondary">{endpoint.response}</p>
                                    </div>
                                    {endpoint.errors && (
                                         <div>
                                            <h5 className="font-semibold text-light-text-primary dark:text-dark-text-primary mb-1">Errors</h5>
                                            <p className="font-mono text-xs text-light-error dark:text-dark-error">{endpoint.errors}</p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                        </div>
                    </section>
                ))}
            </div>
        </div>
    );
};

export default DocsPage;