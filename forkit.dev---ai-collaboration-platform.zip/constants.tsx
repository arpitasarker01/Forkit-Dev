
import React from 'react';
// FIX: Import types for new constants
import { AIModel, PricingTier, ForkData, AggregationJob, UserQuota, WorkspaceMember, ReportedModel } from './types';

// Moved all icon definitions to the top of the file to prevent "used before declaration" errors.
export const SunIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v2.25m6.364.386l-1.591 1.591M21 12h-2.25m-.386 6.364l-1.591-1.591M12 18.75V21m-4.773-4.227l-1.591 1.591M5.25 12H3m4.227-4.773L5.636 5.636M15.75 12a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" />
    </svg>
);

export const MoonIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21.752 15.002A9.718 9.718 0 0118 15.75c-5.385 0-9.75-4.365-9.75-9.75 0-1.33.266-2.597.748-3.752A9.753 9.753 0 003 11.25C3 16.635 7.365 21 12.75 21a9.753 9.753 0 009.002-5.998z" />
    </svg>
);

export const ForkIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
  </svg>
);

export const VoteIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 10.5 12 3m0 0 7.5 7.5M12 3v18" />
  </svg>
);

export const ThumbsUpIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6.633 10.5c.806 0 1.533-.424 2.031-1.08a9.041 9.041 0 012.861-2.4c.723-.384 1.35-.956 1.653-1.715a4.498 4.498 0 00.322-1.672V3a.75.75 0 01.75-.75A2.25 2.25 0 0116.5 4.5c0 1.152-.26 2.243-.723 3.218-.266.558.107 1.282.725 1.282h3.126c1.026 0 1.945.694 2.054 1.715.045.422.068.85.068 1.285a11.95 11.95 0 01-2.649 7.521c-.388.482-.987.729-1.605.729H13.48c-.483 0-.964-.078-1.423-.23l-3.114-1.04a4.501 4.501 0 00-1.423-.23H5.904M6.633 10.5l-1.842 1.842a.75.75 0 00-.217 1.061l3.758 6.116A.75.75 0 0010.023 21h1.028a.75.75 0 00.729-.634l.89-4.451m.89-4.451l.89-4.451m0 0a.75.75 0 01.729-.634h1.028a.75.75 0 01.729.634l.89 4.451m-1.282-4.451L15 12a4.5 4.5 0 01-3.232 4.451l-3.114 1.04a4.5 4.5 0 01-1.423.23H5.904M6.633 10.5v5.172" />
    </svg>
);

export const ThumbsDownIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M7.864 4.243A7.5 7.5 0 0119.5 10.5c0 2.92-.556 5.709-1.588 8.188a11.953 11.953 0 01-3.595 3.437c-.723.384-1.35.956-1.653 1.715a4.498 4.498 0 00-.322 1.672v.666a.75.75 0 01-.75.75A2.25 2.25 0 0110.5 18c0-1.152.26-2.243.723-3.218.266-.558-.107-1.282-.725-1.282h-3.126c-1.026 0-1.945-.694-2.054-1.715a11.94 11.94 0 01-.068-1.285c0-2.953 1.12-5.714 3.016-7.794l.24-.268zM7.864 4.243l-1.842-1.842a.75.75 0 00-1.061 0l-1.842 1.842a.75.75 0 000 1.061l1.842 1.842a.75.75 0 001.061 0l1.842-1.842a.75.75 0 000-1.061z" />
    </svg>
);

export const DownloadIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
    </svg>
);

export const PlaygroundIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.348a1.125 1.125 0 010 1.971l-11.54 6.347a1.125 1.125 0 01-1.667-.985V5.653z" />
    </svg>
);

export const ProvenanceIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.286zm0 13.036h.008v.015h-.008v-.015z" />
    </svg>
);

export const WorkspaceIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 14.15v4.05a2.25 2.25 0 01-2.25 2.25h-15A2.25 2.25 0 01.75 18.2V6.75A2.25 2.25 0 013 4.5h15a2.25 2.25 0 012.25 2.25v.75m-8.25-9v2.25m0 0a2.25 2.25 0 012.25 2.25M12 3a2.25 2.25 0 00-2.25 2.25m0 11.25a2.25 2.25 0 012.25-2.25m0 0a2.25 2.25 0 002.25-2.25m-4.5 0a2.25 2.25 0 012.25-2.25M12 13.5a2.25 2.25 0 00-2.25-2.25M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
    </svg>
);

export const AggregationIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 15l3-3m0 0l-3-3m3 3h-7.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

export const ShieldIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.286z" />
  </svg>
);

export const UploadIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
    </svg>
);

export const CheckCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

export const ClockIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export const XCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

export const SuccessIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

export const ErrorIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

export const InfoIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="m11.25 11.25.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0Zm-9-3.75h.008v.008H12V8.25Z" />
    </svg>
);

export const PlusCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v6m3-3H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export const DocumentCheckIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75l2.25 2.25 4.5-4.5m-8.25 6L3 16.5v-9a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v9a2.25 2.25 0 01-2.25 2.25H5.25z" />
  </svg>
);

export const CreditCardIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5z" />
    </svg>
);

export const TagIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9.568 3H5.25A2.25 2.25 0 003 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 005.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.66A2.25 2.25 0 009.568 3z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 6h.008v.008H6V6z" />
    </svg>
);

export const CogIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12a7.5 7.5 0 0015 0m-15 0a7.5 7.5 0 1115 0m-15 0H3m18 0h-1.5m-15.036-6.364l-1.06-1.06M21.75 16.5l-1.06-1.06m-14.12 2.12l-1.06 1.06M21.75 7.5l-1.06 1.06M12 21v-1.5m0-15V3" />
    </svg>
);

export const RocketIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.82m5.84-2.56a12.022 12.022 0 01-12.022 12.022A12.022 12.022 0 013.37 5.59m12.22 8.78a6 6 0 00-7.38-5.84m7.38 5.84l2.08-2.08m-2.08 2.08l-2.08-2.08m2.08 2.08l2.08-2.08m-14.28-4.28L5.59 3.37m0 0l2.08 2.08M5.59 3.37l2.08-2.08M5.59 3.37l-2.08 2.08m14.28 4.28a6 6 0 00-5.84-7.38v4.82m5.84 2.56zm-14.28 4.28a12.022 12.022 0 0112.022-12.022 12.022 12.022 0 01-12.022 12.022z" />
    </svg>
);

export const TokenIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m-3-6h6m9 0a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

// FIX: Add all missing data constants
export const MODELS_DATA: AIModel[] = [
  { id: '1', name: 'QuantumLeap-7B', author: 'SynthAI Labs', authorAvatarUrl: 'https://picsum.photos/seed/synth/40/40', description: 'A foundational model for quantum machine learning.', tags: ['Quantum ML', 'Physics', '7B'], forks: 1204, votes: 8300, provenanceHash: 'QmXo...6uco', task: 'QML Simulation', modelType: 'Transformer', dataset: 'QuantumSet-Alpha', status: 'Verified', downloads: 25600, isFavorite: true, plan: 'Free' },
  { id: '2', name: 'BioVerse-15B', author: 'Genetica', authorAvatarUrl: 'https://picsum.photos/seed/genetica/40/40', description: 'A large-scale model for protein folding and drug discovery.', tags: ['Biology', 'Healthcare', '15B'], forks: 873, votes: 6200, provenanceHash: 'QmYp...9vjw', task: 'Protein Folding', modelType: 'Graph Neural Network', dataset: 'PDB', status: 'Verified', downloads: 18900, plan: 'Pro' },
  { id: '3', name: 'CodeScribe-3B', author: 'DevMind AI', authorAvatarUrl: 'https://picsum.photos/seed/devmind/40/40', description: 'A lightweight model for code generation and autocompletion.', tags: ['Code', 'Developer Tools', '3B'], forks: 2500, votes: 11500, provenanceHash: 'QmZo...2kfx', task: 'Code Generation', modelType: 'Transformer-XL', dataset: 'The Stack', status: 'Verified', downloads: 52300, isFavorite: true, plan: 'Free' },
  { id: '4', name: 'Artisan-Diffusion', author: 'Creative AI Co.', authorAvatarUrl: 'https://picsum.photos/seed/creative/40/40', description: 'A diffusion model for generating high-quality artistic images.', tags: ['Art', 'Image Generation', 'Diffusion'], forks: 1800, votes: 9800, provenanceHash: 'QmAr...8ghz', task: 'Text-to-Image', modelType: 'Diffusion', dataset: 'LAION-5B', status: 'Verified', downloads: 41000, plan: 'Pro' },
  { id: '5', name: 'FinanceLLM-8B', author: 'Numerix', authorAvatarUrl: 'https://picsum.photos/seed/numerix/40/40', description: 'A model trained on financial data for market analysis and prediction.', tags: ['Finance', 'LLM', '8B'], forks: 950, votes: 7100, provenanceHash: 'QmFi...5jkl', task: 'Financial Analysis', modelType: 'LLaMA', dataset: 'BloombergQuint', status: 'Pending', downloads: 15000, approvalExpiresAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), votesRequired: 1000 },
  { id: '6', name: 'MusicGen-4B', author: 'Melodia', authorAvatarUrl: 'https://picsum.photos/seed/melodia/40/40', description: 'A model for generating coherent and novel musical pieces.', tags: ['Music', 'Generative', '4B'], forks: 1100, votes: 8500, provenanceHash: 'QmMu...1abc', task: 'Music Generation', modelType: 'RNN', dataset: 'MIDI-Large', status: 'Pending', downloads: 22000, approvalExpiresAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString(), votesRequired: 1500 },
];

export const PRICING_DATA: PricingTier[] = [
  { name: 'Free', price: '€0', pricePeriod: '/ month', description: 'For individuals and hobbyists starting out.', features: ['5 Aggregations/month', '10 Downloads/month', 'Public Models Only', 'Community Support'], isFeatured: false },
  { name: 'Pro', price: '€49', pricePeriod: '/ month', description: 'For professionals and small teams who need more power.', features: ['50 Aggregations/month', '100 Downloads/month', 'Private Models', 'Email Support', 'Basic Analytics'], isFeatured: true },
  { name: 'Pro Plus', price: '€99', pricePeriod: '/ month', description: 'For growing teams that require advanced features.', features: ['Unlimited Aggregations', 'Unlimited Downloads', 'Advanced Collaboration', 'Priority Support', 'Full API Access'], addons: ['Add-on: Extra Seats', 'Add-on: Usage Packs'], isFeatured: false },
  { name: 'Enterprise', price: 'Custom', pricePeriod: '', description: 'For large organizations with custom needs.', features: ['All Pro Plus Features', 'Dedicated Support', 'Custom Governance', 'On-premise Deployment', 'Full Audit Logs'], isFeatured: false },
];

export const FORK_LINEAGE_DATA: ForkData = {
  id: 'root', name: 'QuantumLeap-7B', author: 'SynthAI Labs',
  children: [
    { id: 'child1', name: 'QL-7B-FineTuned', author: 'Jane Doe', children: [
      { id: 'grandchild1', name: 'QL-7B-FT-Optimized', author: 'AI Enthusiast' }
    ]},
    { id: 'child2', name: 'QuantumLeap-7B-GGUF', author: 'Community Contributor' }
  ]
};

export const AGGREGATION_JOBS_DATA: AggregationJob[] = [
  { id: 'agg-1672532400000', name: 'ImageNet-Fusion', status: 'Done', createdAt: '2023-01-01T12:00:00Z', baseModel: 'VisionNet-50', mergedModels: ['VisionNet-50-A', 'VisionNet-50-B'], metrics: { accuracy: '92.5%', loss: '0.18' }, resultModelId: '2' },
  { id: 'agg-1672618800000', name: 'Code-Synth-Merge', status: 'Running', createdAt: '2023-01-02T14:00:00Z', baseModel: 'CodeScribe-3B', mergedModels: ['CodeScribe-Python', 'CodeScribe-JS'] },
  { id: 'agg-1672705200000', name: 'Bio-Enhancer', status: 'Queued', createdAt: '2023-01-03T16:00:00Z', baseModel: 'BioVerse-15B', mergedModels: ['ProteinFold-Fork', 'DrugDiscovery-FT'] },
  { id: 'agg-1672442400000', name: 'Quantum-Optimization-Fail', status: 'Failed', createdAt: '2022-12-31T10:00:00Z', baseModel: 'QuantumLeap-7B', mergedModels: ['QL-LowRank', 'QL-Distilled'], notes: 'Merge conflict in tensor shapes.' },
];

export const USER_QUOTAS_DATA: UserQuota[] = [
  { name: 'Aggregations', used: 2, total: 5, icon: AggregationIcon },
  { name: 'Downloads', used: 4, total: 10, icon: DownloadIcon },
  { name: 'API Calls', used: 1204, total: 5000, icon: RocketIcon },
  { name: 'Tokens', used: 8, total: 25, icon: TokenIcon },
];

export const WORKSPACE_MEMBERS_DATA: WorkspaceMember[] = [
  { name: 'Jane Doe', email: 'jane.doe@example.com', avatarUrl: 'https://picsum.photos/seed/jane/40/40', role: 'Owner' },
  { name: 'John Smith', email: 'john.smith@example.com', avatarUrl: 'https://picsum.photos/seed/john/40/40', role: 'Admin' },
  { name: 'Alice Johnson', email: 'alice.j@example.com', avatarUrl: 'https://picsum.photos/seed/alice/40/40', role: 'Editor' },
];

export const REPORTED_MODELS_DATA: ReportedModel[] = [
  { id: 'rep-1', modelName: 'Unstable-Diffusion-v3', modelId: '7', reportedBy: 'user-2468', reason: 'Produces harmful and biased content.', reportedAt: new Date().toISOString() },
  { id: 'rep-2', modelName: 'SpamBot-5000', modelId: '8', reportedBy: 'user-1357', reason: 'This model is clearly designed for spamming and is against the terms of service.', reportedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString() },
];

export const API_DOCS_DATA = {
    general: [
        { key: 'Base URL', value: 'https://api.forkit.dev/v1' },
        { key: 'Authentication', value: 'API Key (sent in X-API-Key header)' },
        { key: 'Rate Limit', value: '100 requests/minute' },
    ],
    sections: [
        {
            title: 'Models',
            endpoints: [
                {
                    method: 'GET',
                    path: '/models',
                    description: 'Retrieve a list of all verified models.',
                    request: null,
                    response: 'Array of Model objects.'
                },
                {
                    method: 'GET',
                    path: '/models/{model_id}',
                    description: 'Get details for a specific model.',
                    request: null,
                    response: 'A single Model object.',
                    errors: '404 - Model not found'
                },
            ]
        },
        {
            title: 'Aggregation',
            endpoints: [
                 {
                    method: 'POST',
                    path: '/aggregation/jobs',
                    description: 'Create a new aggregation job.',
                    request: { type: 'JSON', params: ['jobName: string', 'baseModelId: string', 'mergedModelIds: string[]'] },
                    response: 'The newly created AggregationJob object.',
                    errors: '400 - Invalid parameters'
                },
            ]
        }
    ]
};
