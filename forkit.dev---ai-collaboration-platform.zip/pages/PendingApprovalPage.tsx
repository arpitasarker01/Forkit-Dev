
import React, { useState, useMemo } from 'react';
import { MODELS_DATA } from '../constants';
import { Page, NotificationType, AIModel } from '../types';
import PendingModelCard from '../components/PendingModelCard';

interface PendingApprovalPageProps {
  navigateTo: (page: Page, modelId?: string) => void;
  addToast: (message: string, type: NotificationType) => void;
}

const PendingApprovalPage: React.FC<PendingApprovalPageProps> = ({ navigateTo, addToast }) => {
  const [votedIds, setVotedIds] = useState<Set<string>>(new Set());
  const [currentPendingModels, setCurrentPendingModels] = useState<AIModel[]>(() => MODELS_DATA.filter(m => m.status === 'Pending'));

  const handleVote = (model: AIModel) => {
    setVotedIds(prev => new Set(prev).add(model.id));
    
    const newVoteCount = model.votes + 1;
    if (newVoteCount >= (model.votesRequired || Infinity)) {
        addToast(`Vote threshold reached! '${model.name}' has been verified.`, 'success');
        setCurrentPendingModels(prev => prev.filter(m => m.id !== model.id));
    } else {
        addToast(`Successfully voted to approve '${model.name}'!`, 'success');
    }
  };

  return (
    <div className="container mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-light-text-primary dark:text-dark-text-primary">Pending Approval</h2>
        <p className="text-light-text-secondary dark:text-dark-text-secondary mt-2">These models are awaiting community verification. Your vote matters!</p>
      </div>

      {currentPendingModels.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {currentPendingModels.map(model => (
            <PendingModelCard 
              key={model.id} 
              model={model}
              onVote={() => handleVote(model)}
              hasVoted={votedIds.has(model.id)}
              navigateTo={navigateTo}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center text-center border-2 border-dashed border-light-border dark:border-dark-border rounded-lg py-24">
            <h3 className="mt-2 text-xl font-semibold text-light-text-primary dark:text-dark-text-primary">No models pending approval</h3>
            <p className="mt-1 text-sm text-light-text-secondary dark:text-dark-text-secondary">Check back later to help govern the community.</p>
        </div>
      )}
    </div>
  );
};

export default PendingApprovalPage;
