
import React, { useState } from 'react';
import { Page, AggregationJob, NotificationType } from '../types';
import { MODELS_DATA, AGGREGATION_JOBS_DATA, AggregationIcon, CheckCircleIcon, ClockIcon, XCircleIcon } from '../constants';

const AggregationJobItem: React.FC<{ job: AggregationJob, navigateTo: (page: Page, modelId?: string) => void }> = ({ job, navigateTo }) => {
    const statusInfo = {
        Done: {
            classes: 'bg-light-success/10 text-light-success dark:bg-dark-info/10 dark:text-dark-info',
            Icon: CheckCircleIcon
        },
        Running: {
            classes: 'bg-light-info/10 text-light-info dark:bg-dark-info/10 dark:text-dark-info',
            Icon: (props: React.SVGProps<SVGSVGElement>) => <ClockIcon {...props} className="animate-spin" />
        },
        Queued: {
            classes: 'bg-light-warning/10 text-light-warning dark:bg-dark-warning/10 dark:text-dark-warning',
            Icon: ClockIcon
        },
        Failed: {
            classes: 'bg-light-error/10 text-light-error dark:bg-dark-error/10 dark:text-dark-error',
            Icon: XCircleIcon
        },
    };

    const { classes, Icon } = statusInfo[job.status];
    const isClickable = job.status === 'Done' && job.resultModelId;
    const itemClasses = isClickable ? 'cursor-pointer hover:border-light-accent-primary dark:hover:border-dark-accent-primary' : '';

    return (
        <div onClick={() => isClickable && navigateTo('modelDetails', job.resultModelId)} className={`bg-light-bg-secondary dark:bg-dark-bg-secondary p-4 rounded-lg border border-light-border dark:border-dark-border flex items-start justify-between gap-4 transition-colors ${itemClasses}`}>
            <div>
                <p className="font-semibold text-light-text-primary dark:text-dark-text-primary">{job.name}</p>
                <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary mt-1">Base: {job.baseModel}</p>
                 {job.metrics && (
                    <p className="text-xs text-light-text-primary dark:text-dark-text-primary mt-2 font-mono">Accuracy: {job.metrics.accuracy}, Loss: {job.metrics.loss}</p>
                )}
                 {isClickable && <p className="text-xs text-light-accent-primary dark:text-dark-accent-primary mt-2">View Result Model &rarr;</p>}
            </div>
            <div className={`flex-shrink-0 text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5 ${classes}`}>
                <Icon className="w-4 h-4" />
                <span>{job.status}</span>
            </div>
        </div>
    );
};

interface AggregationPageProps {
    addToast: (message: string, type: NotificationType) => void;
    navigateTo: (page: Page, modelId?: string) => void;
}

const AggregationPage: React.FC<AggregationPageProps> = ({ addToast, navigateTo }) => {
    const [jobs, setJobs] = useState<AggregationJob[]>(AGGREGATION_JOBS_DATA);
    const [jobName, setJobName] = useState('');
    const [baseModel, setBaseModel] = useState(MODELS_DATA[0]?.id || '');
    const [selectedModels, setSelectedModels] = useState<Set<string>>(new Set());
    const [notes, setNotes] = useState('');

    const handleModelToggle = (modelId: string) => {
        setSelectedModels(prev => {
            const newSet = new Set(prev);
            if (newSet.has(modelId)) {
                newSet.delete(modelId);
            } else {
                newSet.add(modelId);
            }
            return newSet;
        });
    };
    
    const handlePreview = () => {
        if(selectedModels.size < 2) {
            addToast('Please select at least 2 models to merge for a preview.', 'error');
            return;
        }
        addToast('Preview metrics: Est. Accuracy 91.8%, Est. Loss 0.21', 'info');
    }

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const newJob: AggregationJob = {
            id: `agg-${Date.now()}`,
            name: jobName,
            status: 'Queued',
            createdAt: new Date().toISOString(),
            baseModel: MODELS_DATA.find(m => m.id === baseModel)?.name || 'Unknown',
            mergedModels: Array.from(selectedModels).map(id => MODELS_DATA.find(m => m.id === id)?.name || 'Unknown'),
            notes: notes,
        };
        setJobs(prev => [newJob, ...prev]);
        addToast(`Job '${jobName}' has been queued.`, 'success');
        setJobName('');
        setBaseModel(MODELS_DATA[0]?.id || '');
        setSelectedModels(new Set());
        setNotes('');
    };

    return (
        <div className="container mx-auto">
            <div className="mb-8">
                <h2 className="text-3xl font-bold text-light-text-primary dark:text-dark-text-primary">Model Aggregation</h2>
                <p className="text-light-text-secondary dark:text-dark-text-secondary mt-2">Combine models to create powerful new aggregations.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
                {/* Form */}
                <div className="lg:col-span-2">
                    <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary border border-light-border dark:border-dark-border rounded-lg p-6">
                        <h3 className="text-lg font-semibold text-light-text-primary dark:text-dark-text-primary mb-4">Create Aggregation Job</h3>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label className="text-sm font-medium text-light-text-secondary dark:text-dark-text-secondary block mb-1.5">Job Name</label>
                                <input type="text" value={jobName} onChange={e => setJobName(e.target.value)} required className="w-full bg-light-bg dark:bg-dark-bg border border-light-border dark:border-dark-border rounded-md text-sm text-light-text-primary dark:text-dark-text-primary p-2 focus:ring-light-accent-primary dark:focus:ring-dark-accent-primary" placeholder="e.g., QuantumLeap-7B-Enhanced" />
                            </div>
                             <div>
                                <label className="text-sm font-medium text-light-text-secondary dark:text-dark-text-secondary block mb-1.5">Select Base Model</label>
                                <select value={baseModel} onChange={e => setBaseModel(e.target.value)} className="w-full bg-light-bg dark:bg-dark-bg border border-light-border dark:border-dark-border rounded-md text-sm text-light-text-primary dark:text-dark-text-primary p-2 focus:ring-light-accent-primary dark:focus:ring-dark-accent-primary">
                                    {MODELS_DATA.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                                </select>
                            </div>
                             <div>
                                <label className="text-sm font-medium text-light-text-secondary dark:text-dark-text-secondary block mb-1.5">Select Models to Merge (2+)</label>
                                <div className="max-h-40 overflow-y-auto space-y-2 p-3 bg-light-bg dark:bg-dark-bg rounded-md border border-light-border dark:border-dark-border">
                                    {MODELS_DATA.filter(m => m.id !== baseModel).map(m => (
                                        <label key={m.id} className="flex items-center gap-2 text-sm text-light-text-primary dark:text-dark-text-primary cursor-pointer">
                                            <input type="checkbox" checked={selectedModels.has(m.id)} onChange={() => handleModelToggle(m.id)} className="rounded bg-light-bg-secondary dark:bg-dark-bg-secondary border-light-border dark:border-dark-border text-light-accent-primary dark:text-dark-accent-primary focus:ring-light-accent-primary dark:focus:ring-dark-accent-primary" />
                                            {m.name}
                                        </label>
                                    ))}
                                </div>
                            </div>
                             <div className="flex gap-2">
                                <button type="button" onClick={handlePreview} className="w-full bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-semibold py-2.5 rounded-lg transition-colors duration-200">Preview</button>
                                <button type="submit" className="w-full bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-semibold py-2.5 rounded-lg transition-colors duration-200 disabled:opacity-50" disabled={selectedModels.size < 2 || !jobName}>
                                    Run
                                </button>
                             </div>
                        </form>
                    </div>
                </div>

                {/* Job List */}
                <div className="lg:col-span-3">
                     <h3 className="text-lg font-semibold text-light-text-primary dark:text-dark-text-primary mb-4">Job Status</h3>
                     <div className="space-y-4">
                        {jobs.map(job => <AggregationJobItem key={job.id} job={job} navigateTo={navigateTo} />)}
                     </div>
                </div>
            </div>
        </div>
    );
};

export default AggregationPage;
