
import React from 'react';
import { Theme } from '../types';

interface FooterProps {
    theme: Theme;
}

const Footer: React.FC<FooterProps> = ({ theme }) => {
    // Use the contrasting logo version for better visibility.
    const logoSrc = theme === 'dark' ? "/assets/logo-light.svg" : "/assets/logo-dark.svg";

    return (
        <footer className="bg-light-bg-secondary dark:bg-dark-bg-secondary border-t border-light-border dark:border-dark-border">
            <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
                <nav className="flex flex-wrap justify-center -mx-5 -my-2" aria-label="Footer">
                    {['About', 'Contact', 'Terms', 'Privacy', 'Cookies', 'Status Page'].map((item) => (
                        <div key={item} className="px-5 py-2">
                            <a href="#" className="text-base text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary">
                                {item}
                            </a>
                        </div>
                    ))}
                </nav>
                <div className="mt-8 flex justify-center space-x-6">
                   <img src={logoSrc} alt="Forkit.dev logo" className="h-8 w-auto" />
                </div>
                <p className="mt-8 text-center text-base text-light-text-secondary dark:text-dark-text-secondary">
                    &copy; {new Date().getFullYear()} Forkit.dev. All rights reserved.
                </p>
            </div>
        </footer>
    );
}

export default Footer;