
import React, { useState, useEffect } from 'react';
import { AIModel, Page } from '../types';

interface PendingModelCardProps {
  model: AIModel;
  hasVoted: boolean;
  onVote: (modelId: string) => void;
  navigateTo: (page: Page, modelId: string) => void;
}

const calculateTimeLeft = (expiryDate: string) => {
    const difference = +new Date(expiryDate) - +new Date();
    let timeLeft = { days: 0, hours: 0, minutes: 0, seconds: 0 };

    if (difference > 0) {
        timeLeft = {
            days: Math.floor(difference / (1000 * 60 * 60 * 24)),
            hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
            minutes: Math.floor((difference / 1000 / 60) % 60),
            seconds: Math.floor((difference / 1000) % 60),
        };
    }
    return timeLeft;
};

const PendingModelCard: React.FC<PendingModelCardProps> = ({ model, hasVoted, onVote, navigateTo }) => {
  const { approvalExpiresAt, votes, votesRequired } = model;
  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft(approvalExpiresAt || ''));

  useEffect(() => {
    if (!approvalExpiresAt) return;
    const timer = setTimeout(() => {
      setTimeLeft(calculateTimeLeft(approvalExpiresAt));
    }, 1000);
    return () => clearTimeout(timer);
  });

  const votesNeeded = Math.max(0, (votesRequired || 0) - votes);
  const voteProgress = votesRequired ? (votes / votesRequired) * 100 : 0;

  return (
    <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary border border-light-border dark:border-dark-border rounded-lg p-5 flex flex-col h-full">
        <div>
            <h3 className="font-bold text-lg text-light-text-primary dark:text-dark-text-primary">{model.name}</h3>
            <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">by {model.author}</p>
        </div>
        
        <div className="my-4 space-y-2">
            <div>
                <div className="flex justify-between mb-1">
                    <span className="text-xs font-medium text-light-text-secondary dark:text-dark-text-secondary">Votes: {votes} / {votesRequired}</span>
                    <span className="text-xs font-medium text-light-accent-primary dark:text-dark-accent-primary">{votesNeeded} more to verify</span>
                </div>
                <div className="w-full bg-light-bg dark:bg-dark-bg rounded-full h-2.5">
                    <div className="bg-light-accent-primary dark:bg-dark-accent-primary h-2.5 rounded-full" style={{width: `${voteProgress}%`}}></div>
                </div>
            </div>
             <div>
                <p className="text-center text-xs text-light-text-secondary dark:text-dark-text-secondary">Voting ends in:</p>
                <p className="text-center font-mono text-sm text-light-text-primary dark:text-dark-text-primary tracking-wider">
                    {timeLeft.days}d {timeLeft.hours}h {timeLeft.minutes}m {timeLeft.seconds}s
                </p>
            </div>
        </div>

        <div className="mt-auto pt-4 border-t border-light-border dark:border-dark-border space-y-2">
            <button 
                onClick={() => onVote(model.id)}
                disabled={hasVoted}
                className="w-full bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-semibold py-2 px-3 rounded-lg text-sm transition-colors duration-200 disabled:bg-light-border dark:disabled:bg-dark-border disabled:text-light-text-secondary dark:disabled:text-dark-text-secondary disabled:cursor-not-allowed"
            >
                {hasVoted ? 'Voted' : 'Approve'}
            </button>
            <button 
                onClick={() => navigateTo('modelDetails', model.id)}
                className="w-full bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-3 rounded-lg text-sm transition-colors duration-200"
            >
                View Details
            </button>
        </div>
    </div>
  );
};

export default PendingModelCard;
