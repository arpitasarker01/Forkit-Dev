
export interface User {
    id: string;
    name: string;
    email: string;
}

export interface AIModel {
  id: string;
  name: string;
  author: string;
  authorAvatarUrl: string;
  description: string;
  tags: string[];
  forks: number;
  votes: number;
  provenanceHash: string;
  task: string;
  modelType: string;
  dataset: string;
  status: 'Pending' | 'Verified';
  downloads: number;
  approvalExpiresAt?: string;
  votesRequired?: number;
  isFavorite?: boolean;
  plan?: 'Free' | 'Pro';
}

export interface PricingTier {
  name: string;
  price: string;
  pricePeriod: string;
  description: string;
  features: string[];
  addons?: string[];
  isFeatured: boolean;
}

export interface ForkData {
    id: string;
    name: string;
    author: string;
    children?: ForkData[];
}

export interface AggregationJob {
    id: string;
    name: string;
    status: 'Queued' | 'Running' | 'Done' | 'Failed';
    createdAt: string;
    baseModel: string;
    mergedModels: string[];
    notes?: string;
    metrics?: {
        accuracy: string;
        loss: string;
    };
    resultModelId?: string;
}

export interface UserQuota {
    name: string;
    used: number;
    total: number;
    icon: React.ElementType;
}

export type NotificationType = 'success' | 'error' | 'info';

export interface Notification {
  id: string;
  message: string;
  type: NotificationType;
}

// FIX: Added PanelNotification type for use in the Header notifications dropdown.
export interface PanelNotification {
    id: string;
    message: string;
    timestamp: string;
    read: boolean;
    page: Page;
    modelId?: string;
}

export type Theme = 'light' | 'dark';

export interface WorkspaceMember {
    name: string;
    email: string;
    avatarUrl: string;
    role: 'Owner' | 'Admin' | 'Editor' | 'Viewer';
}

export interface ReportedModel {
    id: string;
    modelName: string;
    modelId: string;
    reportedBy: string;
    reason: string;
    reportedAt: string;
}

export type Page = 'home' | 'dashboard' | 'pricing' | 'modelDetails' | 'pendingApproval' | 'aggregation' | 'profile' | 'auth' | 'workspace' | 'admin';
