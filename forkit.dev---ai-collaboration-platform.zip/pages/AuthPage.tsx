
import React from 'react';
// FIX: Import User and Page types for props, remove unused Theme import
import { User, Page } from '../types';

interface AuthPageProps {
  // FIX: Change 'onLogin' to 'onLoginSuccess' to match App.tsx and accept user/token
  onLoginSuccess: (user: User, token: string) => void;
  // FIX: Add navigateTo prop
  navigateTo: (page: Page) => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLoginSuccess, navigateTo }) => {
  // FIX: Implement a handler to simulate login and call onLoginSuccess with mock data
  const handleLogin = () => {
    const mockUser: User = { id: '1', name: 'Jane Doe', email: 'jane.doe@example.com' };
    const mockToken = 'fake-jwt-token-for-demo';
    onLoginSuccess(mockUser, mockToken);
  };
  
  return (
    <div className="flex items-center justify-center min-h-screen bg-light-bg dark:bg-dark-bg">
      <div className="w-full max-w-md p-8 space-y-6 bg-light-bg-secondary dark:bg-dark-bg-secondary rounded-xl shadow-lg border border-light-border dark:border-dark-border">
        <h2 className="text-2xl font-bold text-center text-light-text-primary dark:text-dark-text-primary">Welcome to Forkit.dev</h2>
        <p className="text-center text-sm text-light-text-secondary dark:text-dark-text-secondary">
          Please sign in to access your workspace and contribute.
        </p>
        <button
          onClick={handleLogin}
          className="w-full px-4 py-2 font-semibold text-light-accent-text dark:text-dark-accent-text bg-light-accent-primary dark:bg-dark-accent-primary rounded-lg hover:bg-light-accent-primary-hover dark:hover:bg-dark-accent-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-light-accent-primary dark:focus:ring-dark-accent-primary"
        >
          Sign In (Simulated)
        </button>
        <p className="text-xs text-center text-light-text-secondary dark:text-dark-text-secondary">
          In a real application, this would be a full login form with email/password and OAuth options.
        </p>
      </div>
    </div>
  );
};

export default AuthPage;
