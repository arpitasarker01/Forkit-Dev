
import React, { useState } from 'react';
import { PRICING_DATA } from '../constants';
import PricingCard from '../components/PricingCard';
import Modal from '../components/Modal';
// FIX: Import Page type for navigateTo prop
import { PricingTier, NotificationType, Page } from '../types';

interface PricingPageProps {
    addToast: (message: string, type: NotificationType) => void;
    // FIX: Add navigateTo to props to match usage in App.tsx
    navigateTo: (page: Page) => void;
}

const PricingPage: React.FC<PricingPageProps> = ({ addToast, navigateTo }) => {
    const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
    const [isContactModalOpen, setIsContactModalOpen] = useState(false);
    const [selectedTier, setSelectedTier] = useState<PricingTier | null>(null);

    const handleTierSelect = (tier: PricingTier) => {
        setSelectedTier(tier);
        if (tier.name === 'Enterprise') {
            setIsContactModalOpen(true);
        } else {
            setIsCheckoutModalOpen(true);
        }
    };
    
    const handleCheckout = () => {
        addToast(`Thank you for choosing the ${selectedTier?.name} plan!`, 'success');
        setIsCheckoutModalOpen(false);
    }
    
    const handleContactSubmit = () => {
        addToast('Our sales team will be in touch shortly!', 'success');
        setIsContactModalOpen(false);
    }

    return (
        <div className="container mx-auto">
            <div className="text-center mb-12">
                <h2 className="text-4xl font-extrabold text-light-text-primary dark:text-dark-text-primary sm:text-5xl">
                    Find the plan that's right for you.
                </h2>
                <p className="mt-4 text-xl text-light-text-secondary dark:text-dark-text-secondary">
                    From solo projects to enterprise solutions, our plans scale with your needs.
                </p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start max-w-7xl mx-auto relative">
                {PRICING_DATA.map(tier => (
                    <PricingCard key={tier.name} tier={tier} onButtonClick={() => handleTierSelect(tier)} />
                ))}
            </div>

            <div className="max-w-4xl mx-auto mt-16 text-center">
                <h3 className="text-2xl font-bold text-light-text-primary dark:text-dark-text-primary">Flexible Add-ons</h3>
                <p className="mt-2 text-light-text-secondary dark:text-dark-text-secondary">Scale your Pro Plus or Enterprise plan with additional resources as you grow.</p>
                <div className="mt-6 flex flex-col sm:flex-row justify-center gap-6">
                    <div className="flex-1 bg-light-bg-secondary dark:bg-dark-bg-secondary p-6 rounded-lg border border-light-border dark:border-dark-border">
                        <h4 className="font-semibold text-light-text-primary dark:text-dark-text-primary">Extra Seats</h4>
                        <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mt-1">€30/seat or +5 for €120/month</p>
                    </div>
                    <div className="flex-1 bg-light-bg-secondary dark:bg-dark-bg-secondary p-6 rounded-lg border border-light-border dark:border-dark-border">
                        <h4 className="font-semibold text-light-text-primary dark:text-dark-text-primary">Usage Packs</h4>
                         <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mt-1">€20 for 5 aggregations, €10 for 50 downloads</p>
                    </div>
                </div>
            </div>

            {/* Checkout Modal */}
            <Modal isOpen={isCheckoutModalOpen} onClose={() => setIsCheckoutModalOpen(false)} title={`Checkout: ${selectedTier?.name} Plan`}>
                <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
                    This is a simulated checkout flow. In a real application, this would integrate with a payment processor like Stripe.
                </p>
                <div className="text-center font-bold text-2xl my-6 text-light-text-primary dark:text-dark-text-primary">
                    Total: {selectedTier?.price} / month
                </div>
                <div className="flex justify-end gap-3">
                    <button onClick={() => setIsCheckoutModalOpen(false)} className="bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-4 rounded-lg text-sm">Cancel</button>
                    <button onClick={handleCheckout} className="bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-4 rounded-lg text-sm">Confirm Purchase</button>
                </div>
            </Modal>
            
            {/* Contact Sales Modal */}
            <Modal isOpen={isContactModalOpen} onClose={() => setIsContactModalOpen(false)} title="Contact Sales for Enterprise Plan">
                <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
                    Please fill out the form below, and our sales team will get back to you shortly to discuss your custom needs.
                </p>
                <form className="space-y-4">
                    <input type="email" placeholder="Your Email Address" className="w-full bg-light-bg dark:bg-dark-bg border border-light-border dark:border-dark-border rounded-md text-sm text-light-text-primary dark:text-dark-text-primary p-2 focus:ring-light-accent-primary dark:focus:ring-dark-accent-primary" />
                    <textarea placeholder="Your message..." className="w-full h-24 bg-light-bg dark:bg-dark-bg border border-light-border dark:border-dark-border rounded-md text-sm text-light-text-primary dark:text-dark-text-primary p-2 focus:ring-light-accent-primary dark:focus:ring-dark-accent-primary"></textarea>
                </form>
                <div className="flex justify-end gap-3 mt-6">
                    <button onClick={() => setIsContactModalOpen(false)} className="bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-4 rounded-lg text-sm">Cancel</button>
                    <button onClick={handleContactSubmit} className="bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-4 rounded-lg text-sm">Submit</button>
                </div>
            </Modal>
        </div>
    );
};

export default PricingPage;
