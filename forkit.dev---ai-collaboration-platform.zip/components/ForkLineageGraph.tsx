
import React from 'react';
import { ForkData } from '../types';

interface ForkNodeProps {
  node: ForkData;
  isRoot?: boolean;
  isLast?: boolean;
}

const ForkNode: React.FC<ForkNodeProps> = ({ node, isRoot = false, isLast = false }) => {
  return (
    <div className="relative pl-8">
      {!isRoot && (
        <>
          {/* Horizontal line */}
          <div className="absolute top-5 -left-2.5 w-4 h-px bg-light-border dark:bg-dark-border"></div>
          {/* Vertical line */}
          <div className={`absolute -top-2.5 -left-2.5 w-px bg-light-border dark:bg-dark-border ${isLast ? 'h-7' : 'h-full'}`}></div>
        </>
      )}

      <div className="relative mb-2">
        <div className="flex items-center">
            <div className="absolute -left-8 top-2.5 z-10 w-5 h-5 bg-light-bg dark:bg-dark-bg border-2 border-light-bg-secondary dark:border-dark-bg-secondary rounded-full"></div>
            <div>
                <p className="text-sm font-semibold text-light-text-primary dark:text-dark-text-primary">{node.name}</p>
                <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary">by {node.author}</p>
            </div>
        </div>
      </div>
      
      {node.children && node.children.length > 0 && (
        <div className="mt-2">
          {node.children.map((child, index) => (
            <ForkNode key={child.id} node={child} isLast={index === (node.children?.length ?? 0) - 1} />
          ))}
        </div>
      )}
    </div>
  );
};


const ForkLineageGraph: React.FC<{ data: ForkData }> = ({ data }) => {
  return (
    <div>
      <ForkNode node={data} isRoot />
    </div>
  );
};

export default ForkLineageGraph;