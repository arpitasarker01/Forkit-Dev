
import React from 'react';
import { UserQuota } from '../types';

interface QuotaMeterProps {
  quota: UserQuota;
}

const QuotaMeter: React.FC<QuotaMeterProps> = ({ quota }) => {
  const { name, used, total, icon: Icon } = quota;
  const percentage = total > 0 ? (used / total) * 100 : 0;

  return (
    <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary p-5 rounded-lg border border-light-border dark:border-dark-border">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Icon className="w-5 h-5 text-light-text-secondary dark:text-dark-text-secondary" />
          <h4 className="font-semibold text-light-text-primary dark:text-dark-text-primary">{name}</h4>
        </div>
        <p className="text-sm font-medium text-light-text-primary dark:text-dark-text-primary">
          {used} / <span className="text-light-text-secondary dark:text-dark-text-secondary">{total}</span>
        </p>
      </div>
      <div className="w-full bg-light-bg dark:bg-dark-bg rounded-full h-2">
        <div
          className="bg-light-accent-primary dark:bg-dark-accent-primary h-2 rounded-full"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );
};

export default QuotaMeter;