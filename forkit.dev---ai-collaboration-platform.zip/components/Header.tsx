
import React, { useState, useRef, useEffect } from 'react';
// FIX: Correctly import PanelNotification and add User type
import { Page, NotificationType, Theme, PanelNotification, User } from '../types';
// FIX: Correctly import USER_QUOTAS_DATA and WorkspaceIcon
import { SunIcon, MoonIcon, USER_QUOTAS_DATA, WorkspaceIcon } from '../constants';

interface HeaderProps {
    navigateTo: (page: Page, modelId?: string) => void;
    addToast: (message: string, type: NotificationType) => void;
    theme: Theme;
    toggleTheme: () => void;
    isAuthenticated: boolean;
    onLogout: () => void;
    notifications: PanelNotification[];
    markNotificationsAsRead: () => void;
    // FIX: Add currentUser to the props interface
    currentUser: User | null;
}

const Header: React.FC<HeaderProps> = ({ navigateTo, addToast, theme, toggleTheme, isAuthenticated, onLogout, notifications, markNotificationsAsRead, currentUser }) => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  
  const profileDropdownRef = useRef<HTMLDivElement>(null);
  const notificationsDropdownRef = useRef<HTMLDivElement>(null);

  // Use the contrasting logo version for better visibility.
  const logoSrc = theme === 'dark' ? "/assets/logo-dark.svg" : "/assets/logo-light.svg";

  const quickQuotas = USER_QUOTAS_DATA.filter(q => q.name === 'Aggregations' || q.name === 'Downloads');
  const unreadCount = notifications.filter(n => !n.read).length;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileDropdownRef.current && !profileDropdownRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
      if (notificationsDropdownRef.current && !notificationsDropdownRef.current.contains(event.target as Node)) {
        setIsNotificationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleProfileToggle = () => {
    setIsNotificationsOpen(false);
    setIsProfileOpen(prev => !prev);
  };

  const handleNotificationsToggle = () => {
    if (!isNotificationsOpen) {
      markNotificationsAsRead();
    }
    setIsProfileOpen(false);
    setIsNotificationsOpen(prev => !prev);
  };

  return (
    <header className="flex-shrink-0 bg-light-bg-secondary/80 dark:bg-dark-bg-secondary/80 backdrop-blur-sm border-b border-light-border dark:border-dark-border z-30 sticky top-0">
      <div className="flex items-center justify-between h-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center space-x-8">
            <a href="#" onClick={(e) => { e.preventDefault(); navigateTo('home'); }} className="flex-shrink-0">
                <img src={logoSrc} alt="Forkit.dev logo" className="h-8 w-auto" />
            </a>
            <nav className="hidden md:flex items-center space-x-6">
                <button onClick={() => navigateTo('dashboard')} className="text-sm font-medium text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary transition-colors">Explore</button>
                <button onClick={() => navigateTo('aggregation')} className="text-sm font-medium text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary transition-colors">Aggregation</button>
                <button onClick={() => navigateTo('pricing')} className="text-sm font-medium text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary transition-colors">Pricing</button>
            </nav>
        </div>

        <div className="flex items-center space-x-4">
            <button onClick={toggleTheme} className="text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary">
                {theme === 'dark' ? <SunIcon className="h-6 w-6" /> : <MoonIcon className="h-6 w-6" />}
            </button>
            
            <div className="relative" ref={notificationsDropdownRef}>
                <button onClick={handleNotificationsToggle} className="relative text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary">
                    {unreadCount > 0 && (
                        <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-light-error dark:bg-dark-error text-xs font-bold text-white">{unreadCount}</span>
                    )}
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                    </svg>
                </button>
                {isNotificationsOpen && (
                    <div className="origin-top-right absolute right-0 mt-2 w-80 rounded-md shadow-lg bg-light-bg-secondary dark:bg-dark-bg-secondary ring-1 ring-light-border dark:ring-dark-border z-20 max-h-96 overflow-y-auto">
                        <div className="p-2 sticky top-0 bg-light-bg-secondary dark:bg-dark-bg-secondary">
                            <div className="px-2 py-1 text-sm font-semibold text-light-text-primary dark:text-dark-text-primary">Notifications</div>
                        </div>
                        <div className="border-t border-light-border dark:border-dark-border">
                            {notifications.length > 0 ? (
                                notifications.map(notification => (
                                    <a 
                                        key={notification.id} 
                                        href="#" 
                                        onClick={(e) => { 
                                            e.preventDefault(); 
                                            navigateTo(notification.page, notification.modelId);
                                            setIsNotificationsOpen(false); 
                                        }} 
                                        className={`block px-4 py-3 text-sm text-light-text-secondary dark:text-dark-text-secondary hover:bg-light-bg dark:hover:bg-dark-bg ${!notification.read ? 'bg-light-bg dark:bg-dark-bg' : ''}`}
                                    >
                                        <p className={`font-medium ${!notification.read ? 'text-light-text-primary dark:text-dark-text-primary' : ''}`}>{notification.message}</p>
                                        <p className="text-xs mt-1">{notification.timestamp}</p>
                                    </a>
                                ))
                            ) : (
                                <div className="p-4 text-center text-sm text-light-text-secondary dark:text-dark-text-secondary">No new notifications</div>
                            )}
                        </div>
                    </div>
                )}
            </div>
            <div className="relative" ref={profileDropdownRef}>
                <button 
                    onClick={handleProfileToggle}
                    className="flex text-sm border-2 border-transparent rounded-full focus:outline-none focus:border-light-accent-primary dark:focus:border-dark-accent-primary transition">
                    <img className="h-8 w-8 rounded-full object-cover" src="https://picsum.photos/seed/user/40/40" alt="User profile"/>
                </button>
                {isProfileOpen && (
                    <div className="origin-top-right absolute right-0 mt-2 w-64 rounded-md shadow-lg bg-light-bg-secondary dark:bg-dark-bg-secondary ring-1 ring-light-border dark:ring-dark-border z-20">
                        <div className="p-2">
                            {quickQuotas.map(quota => (
                                <div key={quota.name} className="px-2 py-2">
                                    <div className="flex justify-between items-center text-xs text-light-text-secondary dark:text-dark-text-secondary mb-1">
                                        <span>{quota.name}</span>
                                        <span>{quota.used}/{quota.total}</span>
                                    </div>
                                    <div className="w-full bg-light-bg dark:bg-dark-bg rounded-full h-1.5">
                                        <div
                                        className="bg-light-accent-primary dark:bg-dark-accent-primary h-1.5 rounded-full"
                                        style={{ width: `${(quota.used / quota.total) * 100}%` }}
                                        ></div>
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="border-t border-light-border dark:border-dark-border py-1">
                            <a href="#" onClick={(e) => { e.preventDefault(); navigateTo('profile'); setIsProfileOpen(false); }} className="block px-4 py-2 text-sm text-light-text-secondary dark:text-dark-text-secondary hover:bg-light-bg dark:hover:bg-dark-bg hover:text-light-text-primary dark:hover:text-dark-text-primary">
                                Your Profile
                            </a>
                            <a href="#" onClick={(e) => { e.preventDefault(); navigateTo('workspace'); setIsProfileOpen(false); }} className="flex items-center gap-2 px-4 py-2 text-sm text-light-text-secondary dark:text-dark-text-secondary hover:bg-light-bg dark:hover:bg-dark-bg hover:text-light-text-primary dark:hover:text-dark-text-primary">
                                <WorkspaceIcon className="w-4 h-4" /> Workspace
                            </a>
                             <a href="#" onClick={(e) => { e.preventDefault(); navigateTo('admin'); setIsProfileOpen(false); }} className="block px-4 py-2 text-sm text-light-text-secondary dark:text-dark-text-secondary hover:bg-light-bg dark:hover:bg-dark-bg hover:text-light-text-primary dark:hover:text-dark-text-primary">
                                Admin Panel
                            </a>
                        </div>
                        <div className="border-t border-light-border dark:border-dark-border py-1">
                            <a href="#" onClick={(e) => { e.preventDefault(); onLogout(); setIsProfileOpen(false); }} className="block px-4 py-2 text-sm text-light-text-secondary dark:text-dark-text-secondary hover:bg-light-bg dark:hover:bg-dark-bg hover:text-light-text-primary dark:hover:text-dark-text-primary">
                                Sign out
                            </a>
                        </div>
                    </div>
                )}
            </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
