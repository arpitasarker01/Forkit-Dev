
import React, { useState } from 'react';
import { Page, NotificationType, ReportedModel } from '../types';
import { REPORTED_MODELS_DATA } from '../constants';

interface AdminPageProps {
  addToast: (message: string, type: NotificationType) => void;
  // FIX: Add navigateTo to props to match usage in App.tsx
  navigateTo: (page: Page) => void;
}

const AdminPage: React.FC<AdminPageProps> = ({ addToast }) => {
  const [activeTab, setActiveTab] = useState('Reports Queue');
  const [reports, setReports] = useState<ReportedModel[]>(REPORTED_MODELS_DATA);

  const handleAction = (reportId: string, action: 'Dismiss' | 'Reject') => {
    const report = reports.find(r => r.id === reportId);
    if (!report) return;

    setReports(prev => prev.filter(r => r.id !== reportId));
    if (action === 'Dismiss') {
        addToast(`Report for '${report.modelName}' has been dismissed.`, 'success');
    } else {
        addToast(`Model '${report.modelName}' has been rejected based on the report.`, 'error');
    }
  };

  const TABS = ['Reports Queue', 'Audit Logs'];

  const renderTabContent = () => {
    switch(activeTab) {
        case 'Reports Queue':
            return reports.length > 0 ? (
                <div className="space-y-4">
                    {reports.map(report => (
                        <div key={report.id} className="bg-light-bg-secondary dark:bg-dark-bg-secondary p-5 rounded-lg border border-light-border dark:border-dark-border">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h4 className="font-semibold text-light-text-primary dark:text-dark-text-primary">{report.modelName}</h4>
                                    <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mt-1">Reported by: {report.reportedBy} on {new Date(report.reportedAt).toLocaleDateString()}</p>
                                    <p className="text-sm text-light-text-primary dark:text-dark-text-primary mt-3 p-3 bg-light-bg dark:bg-dark-bg rounded-md border border-light-border dark:border-dark-border">{report.reason}</p>
                                </div>
                                <div className="flex flex-col gap-2 flex-shrink-0 ml-4">
                                    <button onClick={() => handleAction(report.id, 'Dismiss')} className="text-sm bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border font-medium py-2 px-4 rounded-lg">Dismiss</button>
                                    <button onClick={() => handleAction(report.id, 'Reject')} className="text-sm bg-light-error/10 text-light-error dark:bg-dark-error/10 dark:text-dark-error hover:bg-light-error/20 dark:hover:bg-dark-error/20 font-medium py-2 px-4 rounded-lg">Reject Model</button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                 <div className="text-center py-12 border-2 border-dashed border-light-border dark:border-dark-border rounded-lg">
                    <h3 className="text-xl font-semibold text-light-text-primary dark:text-dark-text-primary">All clear!</h3>
                    <p className="mt-1 text-sm text-light-text-secondary dark:text-dark-text-secondary">There are no pending reports.</p>
                </div>
            );
        case 'Audit Logs':
             return <p className="text-light-text-secondary dark:text-dark-text-secondary">A list of all admin actions will appear here.</p>;
        default: return null;
    }
  }

  return (
    <div className="container mx-auto">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-light-text-primary dark:text-dark-text-primary">Admin Moderation Panel</h2>
        <p className="text-light-text-secondary dark:text-dark-text-secondary mt-2">Oversee reports and platform activity.</p>
      </div>

       <div className="mb-6 border-b border-light-border dark:border-dark-border">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          {TABS.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`${
                activeTab === tab
                  ? 'border-light-accent-primary dark:border-dark-accent-primary text-light-accent-primary dark:text-dark-accent-primary'
                  : 'border-transparent text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors`}
            >
              {tab}
            </button>
          ))}
        </nav>
      </div>
      
      <div>{renderTabContent()}</div>
    </div>
  );
};

export default AdminPage;
