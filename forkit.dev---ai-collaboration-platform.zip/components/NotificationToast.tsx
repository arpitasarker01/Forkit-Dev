
import React, { useEffect, useState } from 'react';
import { Notification } from '../types';
import { SuccessIcon, ErrorIcon, InfoIcon } from '../constants';

interface NotificationToastProps {
  notification: Notification;
  onDismiss: () => void;
}

const NotificationToast: React.FC<NotificationToastProps> = ({ notification, onDismiss }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Animate in
    setIsVisible(true);
  }, []);

  const typeStyles = {
    success: {
      bg: 'bg-light-success/10 dark:bg-dark-success/10 border-light-success/30 dark:border-dark-success/30',
      iconColor: 'text-light-success dark:text-dark-success',
      Icon: SuccessIcon,
    },
    error: {
      bg: 'bg-light-error/10 dark:bg-dark-error/10 border-light-error/30 dark:border-dark-error/30',
      iconColor: 'text-light-error dark:text-dark-error',
      Icon: ErrorIcon,
    },
    info: {
      bg: 'bg-light-info/10 dark:bg-dark-info/10 border-light-info/30 dark:border-dark-info/30',
      iconColor: 'text-light-info dark:text-dark-info',
      Icon: InfoIcon,
    },
  };

  const { bg, iconColor, Icon } = typeStyles[notification.type];

  return (
    <div
      className={`
        w-full p-4 rounded-lg shadow-lg flex items-start gap-4 transition-all duration-300 backdrop-blur-sm border
        bg-light-bg-secondary/80 dark:bg-dark-bg-secondary/80
        ${bg}
        ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}
      `}
    >
      <div className={`flex-shrink-0 ${iconColor}`}>
        <Icon className="w-6 h-6" />
      </div>
      <div className="flex-grow text-sm text-light-text-primary dark:text-dark-text-primary">
        {notification.message}
      </div>
      <button onClick={onDismiss} className="flex-shrink-0 text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>
  );
};

export default NotificationToast;