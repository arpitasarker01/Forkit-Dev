
import React from 'react';
import { Page, Theme } from '../types';
import ParticleCanvas from '../components/ParticleCanvas';
import { PRICING_DATA, SunIcon, MoonIcon } from '../constants';
import PricingCard from '../components/PricingCard';
import Footer from '../components/Footer';
import { ForkIcon, VoteIcon, ProvenanceIcon, WorkspaceIcon, AggregationIcon } from '../constants';

interface HomePageProps {
  navigateTo: (page: Page) => void;
  theme: Theme;
  toggleTheme: () => void;
}

const stats = [
    { name: 'Models Uploaded', value: '12,492' },
    { name: 'Verified Forks', value: '87,341' },
    { name: 'Aggregations', value: '3,456' },
];

const features = [
    { name: 'Forking', description: 'Iterate on existing models. Your contributions are tracked and verifiable.', icon: ForkIcon },
    { name: 'Voting', description: 'Upvote high-quality models to help the best ideas surface to the top.', icon: VoteIcon },
    { name: 'Aggregation', description: 'Combine insights from multiple forks to create superior, aggregated models.', icon: AggregationIcon },
    { name: 'Provenance', description: 'Immutable lineage for every model, ensuring trust and transparency via IOTA/IPFS.', icon: ProvenanceIcon },
    { name: 'Workspaces', description: 'Private, collaborative environments for your team to work on proprietary models.', icon: WorkspaceIcon },
]

const timelineSteps = [
    { name: 'Upload & Hash', description: 'Securely upload your model. It gets a unique, verifiable hash on IPFS/IOTA.' },
    { name: 'Vote & Fork', description: 'The community provides feedback, votes on, and forks your model to improve it.' },
    { name: 'Aggregate', description: 'Optionally, aggregate the best forks back into your model to evolve its capabilities.' },
];

const HomePage: React.FC<HomePageProps> = ({ navigateTo, theme, toggleTheme }) => {
  // Use the contrasting logo version for better visibility.
  const logoSrc = theme === 'dark' ? "/assets/logo-dark.svg" : "/assets/logo-light.svg";
  
  return (
    <div className="bg-light-bg dark:bg-dark-bg text-light-text-primary dark:text-dark-text-primary antialiased">
      {/* Header for Home Page */}
      <header className="absolute top-0 left-0 right-0 z-20">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
            <a href="#" onClick={(e) => { e.preventDefault(); navigateTo('home'); }} className="flex-shrink-0">
                <img src={logoSrc} alt="Forkit.dev logo" className="h-8 w-auto" />
            </a>
            <div className="flex items-center space-x-4">
                <button onClick={() => navigateTo('auth')} className="text-sm font-medium text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary transition-colors">Log In</button>
                <button onClick={() => navigateTo('auth')} className="bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-semibold py-2 px-4 rounded-lg text-sm transition-colors duration-200">
                    Sign Up
                </button>
                <button onClick={toggleTheme} className="text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary p-2 rounded-full bg-light-bg-secondary/20 dark:bg-dark-bg-secondary/20">
                    {theme === 'dark' ? <SunIcon className="h-5 w-5" /> : <MoonIcon className="h-5 w-5" />}
                </button>
            </div>
        </div>
      </header>


      {/* Hero Section */}
      <div className="relative h-screen flex items-center justify-center text-center overflow-hidden">
        <ParticleCanvas theme={theme} />
        <div className="relative z-10 p-4">
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tighter mb-4 bg-clip-text text-transparent bg-gradient-to-br from-light-accent-primary to-light-accent-secondary dark:from-dark-accent-primary dark:to-dark-accent-secondary">
            Fork, Vote, Evolve
          </h1>
          <p className="text-xl md:text-2xl text-light-text-secondary dark:text-dark-text-secondary max-w-3xl mx-auto mb-8">
            AI Collaboration that’s Open and Secure.
          </p>
          <div className="flex justify-center items-center gap-x-4 mb-8">
              <span className="bg-light-bg-secondary/50 dark:bg-dark-bg-secondary/50 backdrop-blur-sm border border-light-border dark:border-dark-border text-sm px-3 py-1 rounded-full">No Raw Data</span>
              <span className="bg-light-bg-secondary/50 dark:bg-dark-bg-secondary/50 backdrop-blur-sm border border-light-border dark:border-dark-border text-sm px-3 py-1 rounded-full">Immutable Lineage</span>
              <span className="bg-light-bg-secondary/50 dark:bg-dark-bg-secondary/50 backdrop-blur-sm border border-light-border dark:border-dark-border text-sm px-3 py-1 rounded-full">EU AI Act Ready</span>
          </div>
          <div className="flex justify-center gap-4">
            <button onClick={() => navigateTo('dashboard')} className="bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-semibold py-3 px-8 rounded-lg transition-transform duration-200 hover:scale-105">
              Explore Models
            </button>
            <button onClick={() => navigateTo('workspace')} className="bg-light-accent-secondary hover:bg-light-accent-secondary-hover dark:bg-dark-accent-secondary dark:hover:bg-dark-accent-secondary-hover text-light-accent-text dark:text-dark-accent-text font-semibold py-3 px-8 rounded-lg transition-transform duration-200 hover:scale-105">
              Create Workspace
            </button>
          </div>
        </div>
      </div>

      {/* Stats Panel */}
      <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <dl className="grid grid-cols-1 gap-x-8 gap-y-16 text-center lg:grid-cols-3">
            {stats.map((stat) => (
              <div key={stat.name} className="mx-auto flex max-w-xs flex-col gap-y-4">
                <dt className="text-base leading-7 text-light-text-secondary dark:text-dark-text-secondary">{stat.name}</dt>
                <dd className="order-first text-3xl font-semibold tracking-tight text-light-text-primary dark:text-dark-text-primary sm:text-5xl">{stat.value}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
      
      {/* Features Section */}
      <div className="py-24 sm:py-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="max-w-2xl mx-auto lg:text-center">
            <h2 className="text-base font-semibold leading-7 text-light-accent-primary dark:text-dark-accent-primary">Collaborate Better</h2>
            <p className="mt-2 text-3xl font-bold tracking-tight text-light-text-primary dark:text-dark-text-primary sm:text-4xl">Everything you need for decentralized AI development</p>
          </div>
          <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-4xl">
            <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-10 lg:max-w-none lg:grid-cols-2 lg:gap-y-16">
              {features.map((feature) => (
                <div key={feature.name} className="relative pl-16">
                  <dt className="text-base font-semibold leading-7 text-light-text-primary dark:text-dark-text-primary">
                    <div className="absolute left-0 top-0 flex h-10 w-10 items-center justify-center rounded-lg bg-light-accent-primary dark:bg-dark-accent-primary">
                      <feature.icon className="h-6 w-6 text-light-accent-text dark:text-dark-accent-text" aria-hidden="true" />
                    </div>
                    {feature.name}
                  </dt>
                  <dd className="mt-2 text-base leading-7 text-light-text-secondary dark:text-dark-text-secondary">{feature.description}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      </div>

      {/* How it works */}
      <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary py-24 sm:py-32">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
            <div className="max-w-2xl mx-auto text-center">
                 <h2 className="text-3xl font-bold tracking-tight text-light-text-primary dark:text-dark-text-primary sm:text-4xl">How It Works</h2>
                 <p className="mt-4 text-lg text-light-text-secondary dark:text-dark-text-secondary">A simple, transparent, and verifiable workflow.</p>
            </div>
            <div className="mt-16 flow-root">
                <ul className="-mb-8">
                    {timelineSteps.map((event, eventIdx) => (
                    <li key={event.name}>
                        <div className="relative pb-8">
                        {eventIdx !== timelineSteps.length - 1 ? (
                            <span className="absolute left-5 top-5 -ml-px h-full w-0.5 bg-light-border dark:bg-dark-border" aria-hidden="true" />
                        ) : null}
                        <div className="relative flex items-start space-x-3">
                            <div>
                                <div className="relative px-1">
                                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-light-bg dark:bg-dark-bg ring-4 ring-light-bg-secondary dark:ring-dark-bg-secondary">
                                        <span className="text-light-accent-primary dark:text-dark-accent-primary font-bold text-lg">{eventIdx+1}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="min-w-0 flex-1 py-1.5">
                                <div className="text-lg font-semibold text-light-text-primary dark:text-dark-text-primary">{event.name}</div>
                                <div className="mt-1 text-base text-light-text-secondary dark:text-dark-text-secondary">{event.description}</div>
                            </div>
                        </div>
                        </div>
                    </li>
                    ))}
                </ul>
            </div>
        </div>
      </div>
      
      {/* Pricing Preview */}
        <div className="py-24 sm:py-32">
             <div className="container mx-auto">
                <div className="text-center mb-12">
                    <h2 className="text-4xl font-extrabold text-light-text-primary dark:text-dark-text-primary sm:text-5xl">
                        Flexible pricing for teams of any size
                    </h2>
                    <p className="mt-4 text-xl text-light-text-secondary dark:text-dark-text-secondary">
                        Choose the plan that's right for you and your team.
                    </p>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-stretch max-w-7xl mx-auto relative px-6 lg:px-8">
                    {PRICING_DATA.map(tier => (
                        <PricingCard key={tier.name} tier={tier} onButtonClick={() => navigateTo('pricing')} />
                    ))}
                </div>
            </div>
        </div>
      
      <Footer theme={theme} />
    </div>
  );
};

export default HomePage;
