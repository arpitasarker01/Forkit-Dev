
import React from 'react';
import { PricingTier } from '../types';
import { PlusCircleIcon } from '../constants';

const CheckIcon: React.FC = () => (
    <svg className="w-5 h-5 text-light-accent-primary dark:text-dark-accent-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
    </svg>
);

interface PricingCardProps {
    tier: PricingTier;
    onButtonClick: () => void;
}

const PricingCard: React.FC<PricingCardProps> = ({ tier, onButtonClick }) => {
    const cardClasses = tier.isFeatured
        ? 'bg-light-bg-secondary dark:bg-dark-bg-secondary border-light-accent-secondary dark:border-dark-accent-secondary transform md:scale-105 shadow-2xl dark:shadow-dark-accent-secondary/10 shadow-light-accent-secondary/10 z-10'
        : 'bg-light-bg-secondary dark:bg-dark-bg-secondary border-light-border dark:border-dark-border';

    const buttonClasses = tier.isFeatured 
        ? 'bg-light-accent-secondary hover:bg-light-accent-secondary-hover dark:bg-dark-accent-secondary dark:hover:bg-dark-accent-secondary-hover text-light-accent-text dark:text-dark-accent-text' 
        : 'bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text';

    return (
        <div className={`rounded-xl border p-8 flex flex-col ${cardClasses} transition-transform duration-300 h-full`}>
            {tier.isFeatured && (
                <div className="absolute top-0 -translate-y-1/2 bg-light-accent-secondary dark:bg-dark-accent-secondary text-light-accent-text dark:text-dark-accent-text text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider left-1/2 -translate-x-1/2">
                    Most Popular
                </div>
            )}
            <h3 className="text-2xl font-semibold text-light-text-primary dark:text-dark-text-primary text-center">{tier.name}</h3>
            <p className="mt-4 text-center text-light-text-secondary dark:text-dark-text-secondary">{tier.description}</p>
            <div className="mt-6 text-center">
                <span className="text-5xl font-extrabold text-light-text-primary dark:text-dark-text-primary">{tier.price}</span>
                {tier.pricePeriod && <span className="text-base font-medium text-light-text-secondary dark:text-dark-text-secondary">{tier.pricePeriod}</span>}
            </div>
            <ul className="mt-8 space-y-4 flex-grow">
                {tier.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                        <div className="flex-shrink-0 mt-1">
                           <CheckIcon />
                        </div>
                        <span className="ml-3 text-light-text-secondary dark:text-dark-text-secondary">{feature}</span>
                    </li>
                ))}
                {tier.addons && tier.addons.length > 0 && (
                    <div className="pt-4 mt-4 border-t border-light-border dark:border-dark-border">
                        {tier.addons.map((addon, index) => (
                             <li key={index} className="flex items-start">
                                <div className="flex-shrink-0 mt-1">
                                    <PlusCircleIcon className="w-5 h-5 text-light-accent-secondary dark:text-dark-accent-secondary" />
                                </div>
                                <span className="ml-3 text-light-text-secondary dark:text-dark-text-secondary italic">{addon.replace('Add-on: ', '')}</span>
                            </li>
                        ))}
                    </div>
                )}
            </ul>
            <button onClick={onButtonClick} className={`mt-10 w-full py-3 px-6 text-base font-semibold rounded-lg transition-colors duration-300 ${buttonClasses}`}>
                {tier.name === 'Enterprise' ? 'Contact Sales' : 'Choose Plan'}
            </button>
        </div>
    );
};

export default PricingCard;