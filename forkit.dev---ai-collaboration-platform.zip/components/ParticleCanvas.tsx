import React, { useRef, useEffect } from 'react';
import { Theme } from '../types';

interface ParticleCanvasProps {
    theme: Theme;
}

const ParticleCanvas: React.FC<ParticleCanvasProps> = ({ theme }) => {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const themeRef = useRef(theme);

    useEffect(() => {
        themeRef.current = theme;
    }, [theme]);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;

        let animationFrameId: number;
        let particles: Particle[] = [];
        const mouse = { x: -1000, y: -1000, radius: 150 };

        const getColors = () => {
            if (themeRef.current === 'dark') {
                return {
                    particle: 'rgba(249, 193, 140, 0.7)', // light-peach (#f9c18c)
                    line: (opacity: number) => `rgba(106, 167, 171, ${opacity})` // light-teal (#6aa7ab)
                };
            } else {
                return {
                    particle: 'rgba(0, 129, 144, 0.7)', // dark-teal (#008190)
                    line: (opacity: number) => `rgba(244, 147, 85, ${opacity})` // dark-peach (#f49355)
                }
            }
        };

        const resizeCanvas = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };

        const handleMouseMove = (event: MouseEvent) => {
            mouse.x = event.clientX;
            mouse.y = event.clientY;
        };
        
        const handleMouseOut = () => {
             mouse.x = -1000;
             mouse.y = -1000;
        }

        class Particle {
            x: number;
            y: number;
            size: number;
            speedX: number;
            speedY: number;

            constructor(x: number, y: number, size: number, speedX: number, speedY: number) {
                this.x = x;
                this.y = y;
                this.size = size;
                this.speedX = speedX;
                this.speedY = speedY;
            }

            draw() {
                if(!ctx) return;
                ctx.fillStyle = getColors().particle;
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.closePath();
                ctx.fill();
            }

            update() {
                if (!canvas) return;
                if (this.x > canvas.width || this.x < 0) this.speedX = -this.speedX;
                if (this.y > canvas.height || this.y < 0) this.speedY = -this.speedY;

                this.x += this.speedX;
                this.y += this.speedY;

                const dx = mouse.x - this.x;
                const dy = mouse.y - this.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                if(distance < mouse.radius + this.size){
                    if(mouse.x < this.x && this.x < canvas.width - this.size * 10){
                        this.x += 5;
                    }
                    if(mouse.x > this.x && this.x > this.size * 10){
                        this.x -= 5;
                    }
                    if(mouse.y < this.y && this.y < canvas.height - this.size * 10){
                        this.y += 5;
                    }
                    if(mouse.y > this.y && this.y > this.size * 10){
                        this.y -= 5;
                    }
                }
            }
        }
        
        const init = () => {
            particles = [];
            const numberOfParticles = (canvas.height * canvas.width) / 8000;
            for (let i = 0; i < numberOfParticles; i++) {
                const size = (Math.random() * 2) + 1;
                const x = (Math.random() * ((innerWidth - size * 2) - (size * 2)) + size * 2);
                const y = (Math.random() * ((innerHeight - size * 2) - (size * 2)) + size * 2);
                const speedX = (Math.random() * 0.4) - 0.2;
                const speedY = (Math.random() * 0.4) - 0.2;
                particles.push(new Particle(x, y, size, speedX, speedY));
            }
        }

        const animate = () => {
            if(!ctx || !canvas) return;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            for (let i = 0; i < particles.length; i++) {
                particles[i].update();
                particles[i].draw();
            }
            connect();
            animationFrameId = requestAnimationFrame(animate);
        }

        const connect = () => {
            if(!ctx) return;
            let opacityValue = 1;
            for(let a=0; a < particles.length; a++){
                for(let b=a; b < particles.length; b++){
                    const dx = particles[a].x - particles[b].x;
                    const dy = particles[a].y - particles[b].y;
                    const distance = Math.sqrt(dx*dx + dy*dy);
                    
                    if(distance < 120){
                        opacityValue = 1 - (distance/120);
                        ctx.strokeStyle = getColors().line(opacityValue);
                        ctx.lineWidth = 1;
                        ctx.beginPath();
                        ctx.moveTo(particles[a].x, particles[a].y);
                        ctx.lineTo(particles[b].x, particles[b].y);
                        ctx.stroke();
                    }
                }
            }
        }

        resizeCanvas();
        init();
        animate();

        const handleResize = () => {
            resizeCanvas();
            init();
        };

        window.addEventListener('resize', handleResize);
        window.addEventListener('mousemove', handleMouseMove);
        window.addEventListener('mouseout', handleMouseOut);

        return () => {
            window.removeEventListener('resize', handleResize);
            window.removeEventListener('mousemove', handleMouseMove);
            window.removeEventListener('mouseout', handleMouseOut);
            cancelAnimationFrame(animationFrameId);
        };
    }, [theme]); // Rerun effect when theme changes

    return <canvas ref={canvasRef} className="absolute top-0 left-0 w-full h-full z-0" />;
};

export default ParticleCanvas;