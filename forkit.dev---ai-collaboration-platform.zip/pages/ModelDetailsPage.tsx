
import React, { useState, useMemo } from 'react';
import { MODELS_DATA, FORK_LINEAGE_DATA, ThumbsUpIcon, ThumbsDownIcon, ForkIcon as ForkActionIcon } from '../constants';
import { Page, AIModel, NotificationType } from '../types';
import ForkLineageGraph from '../components/ForkLineageGraph';
import Modal from '../components/Modal';

interface ModelDetailsPageProps {
  modelId: string;
  navigateTo: (page: Page, modelId?: string) => void;
  addToast: (message: string, type: NotificationType) => void;
  // FIX: Add 'addModel' to props to allow forking a model
  addModel: (model: AIModel) => void;
}

const ModelDetailsPage: React.FC<ModelDetailsPageProps> = ({ modelId, navigateTo, addToast, addModel }) => {
  const [prompt, setPrompt] = useState('Explain quantum computing in simple terms.');
  const [output, setOutput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isForkModalOpen, setIsForkModalOpen] = useState(false);
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);

  const model = useMemo(() => MODELS_DATA.find(m => m.id === modelId), [modelId]);
  
  const confirmFork = () => {
    if (!model) return;
    const newFork: AIModel = {
        ...model,
        id: Date.now().toString(),
        name: `${model.name} Fork`,
        author: 'Jane Doe', // Logged in user
        votes: 0,
        forks: 0,
        downloads: 0,
        status: 'Verified'
    };
    addModel(newFork);
    addToast(`Successfully forked '${model.name}'!`, 'success');
    setIsForkModalOpen(false);
    navigateTo('modelDetails', newFork.id);
  };
  
  const confirmAuditExport = () => {
      addToast('Audit trail export started.', 'success');
      setIsAuditModalOpen(false);
      // Simulate download
      window.open('about:blank', '_blank');
  }

  if (!model) {
    return (
      <div className="text-center">
        <h2 className="text-2xl font-bold text-light-text-primary dark:text-dark-text-primary">Model not found</h2>
        <button onClick={() => navigateTo('dashboard')} className="mt-4 text-light-accent-primary dark:text-dark-accent-primary hover:underline">
          &larr; Back to Explore
        </button>
      </div>
    );
  }
  
  const handleRun = () => {
      setIsLoading(true);
      setOutput('');
      setTimeout(() => {
          setOutput(`Quantum computing is a type of computing that uses the principles of quantum mechanics to perform calculations. Unlike classical computers that use bits (0s and 1s), quantum computers use qubits, which can be a 0, a 1, or both at the same time (superposition). This allows them to solve certain complex problems much faster than classical computers.`);
          setIsLoading(false);
      }, 1500);
  }

  const statusColor = model.status === 'Verified' 
    ? 'bg-light-success/10 text-light-success dark:bg-dark-info/10 dark:text-dark-info' 
    : 'bg-light-warning/10 text-light-warning dark:bg-dark-warning/10 dark:text-dark-warning';
  const statusDotColor = model.status === 'Verified' 
    ? 'bg-light-success dark:bg-dark-info' 
    : 'bg-light-warning dark:bg-dark-warning';

  return (
    <div className="container mx-auto">
      {/* Header */}
      <div className="mb-8">
        <button onClick={() => navigateTo('dashboard')} className="text-sm text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary mb-4">
          &larr; Back to Explore
        </button>
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div>
            <div className="flex items-center gap-4">
               <h2 className="text-3xl font-bold text-light-text-primary dark:text-dark-text-primary">{model.name}</h2>
               <div className={`text-xs font-medium px-2.5 py-1 rounded-full flex items-center ${statusColor}`}>
                  <span className={`w-2 h-2 mr-2 rounded-full ${statusDotColor}`}></span>
                  {model.status}
                </div>
            </div>
            <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary font-mono mt-2 break-all">{model.provenanceHash}</p>
             <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mt-1">by {model.author}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-8">
            {/* Playground */}
            <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary border border-light-border dark:border-dark-border rounded-lg">
                <div className="p-5 border-b border-light-border dark:border-dark-border">
                   <h3 className="text-lg font-semibold text-light-text-primary dark:text-dark-text-primary">Playground</h3>
                   <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Try the model right here in your browser.</p>
                </div>
                <div className="p-5">
                    <textarea 
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        className="w-full h-32 p-3 bg-light-bg dark:bg-dark-bg border border-light-border dark:border-dark-border rounded-md text-sm text-light-text-primary dark:text-dark-text-primary focus:ring-light-accent-primary dark:focus:ring-dark-accent-primary focus:border-light-accent-primary dark:focus:border-dark-accent-primary"
                        placeholder="Enter your prompt here..."
                    />
                    <button 
                        onClick={handleRun}
                        disabled={isLoading}
                        className="mt-4 bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-semibold py-2 px-6 rounded-lg transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed">
                        {isLoading ? 'Running...' : 'Run'}
                    </button>
                    {output && (
                         <div className="mt-4 p-4 bg-light-bg dark:bg-dark-bg rounded-md">
                            <h4 className="font-semibold text-light-text-primary dark:text-dark-text-primary mb-2">Output:</h4>
                            <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary whitespace-pre-wrap">{output}</p>
                        </div>
                    )}
                </div>
            </div>
            {/* Voting */}
            <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary border border-light-border dark:border-dark-border rounded-lg p-5">
                 <h3 className="text-lg font-semibold text-light-text-primary dark:text-dark-text-primary mb-4">Governance & Actions</h3>
                 <div className="flex flex-col sm:flex-row gap-4">
                    <button className="flex-1 flex items-center justify-center gap-2 bg-light-bg dark:bg-dark-bg hover:bg-light-success/20 dark:hover:bg-dark-info/20 text-light-text-primary dark:text-dark-text-primary font-medium py-2.5 px-4 rounded-lg text-sm transition-colors duration-200 border border-light-border dark:border-dark-border">
                        <ThumbsUpIcon className="w-5 h-5 text-light-success dark:text-dark-info" /> Vote to Use
                    </button>
                     <button className="flex-1 flex items-center justify-center gap-2 bg-light-bg dark:bg-dark-bg hover:bg-light-accent-secondary/20 dark:hover:bg-dark-accent-secondary/20 text-light-text-primary dark:text-dark-text-primary font-medium py-2.5 px-4 rounded-lg text-sm transition-colors duration-200 border border-light-border dark:border-dark-border">
                        <ForkActionIcon className="w-5 h-5 text-light-accent-secondary dark:text-dark-accent-secondary" /> Vote to Fork
                    </button>
                     <button className="flex-1 flex items-center justify-center gap-2 bg-light-bg dark:bg-dark-bg hover:bg-light-warning/20 dark:hover:bg-dark-warning/20 text-light-text-primary dark:text-dark-text-primary font-medium py-2.5 px-4 rounded-lg text-sm transition-colors duration-200 border border-light-border dark:border-dark-border">
                        <ThumbsDownIcon className="w-5 h-5 text-light-warning dark:text-dark-warning" /> Not Useful
                    </button>
                 </div>
                 <div className="mt-4 border-t border-light-border dark:border-dark-border pt-4">
                     <button onClick={() => setIsForkModalOpen(true)} className="w-full bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-semibold py-2.5 px-4 rounded-lg transition-colors duration-200">
                        Fork Model
                    </button>
                 </div>
            </div>
        </div>

        {/* Right Column */}
        <div className="space-y-8">
           {/* Provenance */}
            <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary border border-light-border dark:border-dark-border rounded-lg p-5">
                 <h3 className="text-lg font-semibold text-light-text-primary dark:text-dark-text-primary mb-4">Provenance</h3>
                 <ul className="text-sm space-y-3">
                    <li className="flex justify-between">
                        <span className="text-light-text-secondary dark:text-dark-text-secondary">Model Hash:</span>
                        <span className="font-mono text-light-text-primary dark:text-dark-text-primary truncate">QmXo...6uco</span>
                    </li>
                     <li className="flex justify-between items-center">
                        <span className="text-light-text-secondary dark:text-dark-text-secondary">NFT Status:</span>
                        <span className="text-light-success dark:text-dark-info bg-light-success/10 dark:bg-dark-info/10 px-2 py-0.5 rounded-full text-xs font-medium">Minted</span>
                    </li>
                 </ul>
                 <button onClick={() => setIsAuditModalOpen(true)} className="w-full mt-5 bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-3 rounded-lg text-sm transition-colors">
                    Export Audit Trail
                </button>
            </div>
             {/* Fork Lineage */}
             <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary border border-light-border dark:border-dark-border rounded-lg p-5">
                 <h3 className="text-lg font-semibold text-light-text-primary dark:text-dark-text-primary mb-4">Fork Lineage</h3>
                 <ForkLineageGraph data={FORK_LINEAGE_DATA} />
             </div>
             <button className="mt-3 w-full text-center text-xs text-light-error dark:text-dark-error hover:opacity-80 transition-opacity">
                Report this model
            </button>
        </div>
      </div>
      
      {/* Fork Modal */}
      <Modal isOpen={isForkModalOpen} onClose={() => setIsForkModalOpen(false)} title={`Fork '${model.name}'`}>
          <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
              You are about to create a new fork of this model. This will create a new, linked version in your profile that you can modify.
          </p>
          <div className="flex justify-end gap-3">
              <button onClick={() => setIsForkModalOpen(false)} className="bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-4 rounded-lg text-sm">Cancel</button>
              <button onClick={confirmFork} className="bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-4 rounded-lg text-sm">Confirm Fork</button>
          </div>
      </Modal>

      {/* Audit Export Modal */}
      <Modal isOpen={isAuditModalOpen} onClose={() => setIsAuditModalOpen(false)} title="Export Audit Trail">
          <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
              This will generate a file containing the complete, immutable provenance and history for this model.
          </p>
          <div className="flex justify-end gap-3">
              <button onClick={() => setIsAuditModalOpen(false)} className="bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-4 rounded-lg text-sm">Cancel</button>
              <button onClick={confirmAuditExport} className="bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-4 rounded-lg text-sm">Export</button>
          </div>
      </Modal>
    </div>
  );
};

export default ModelDetailsPage;
