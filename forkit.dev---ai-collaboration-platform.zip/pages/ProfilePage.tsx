
import React, { useState, useMemo } from 'react';
// FIX: Import User type for currentUser prop
import { Page, AggregationJob, NotificationType, AIModel, User } from '../types';
import { USER_QUOTAS_DATA, AGGREGATION_JOBS_DATA, CheckCircleIcon, ClockIcon, XCircleIcon } from '../constants';
import ModelCard from '../components/ModelCard';
import QuotaMeter from '../components/QuotaMeter';
import Modal from '../components/Modal';

interface ProfilePageProps {
  navigateTo: (page: Page, modelId?: string) => void;
  addToast: (message: string, type: NotificationType) => void;
  models: AIModel[];
  addModel: (model: AIModel) => void;
  // FIX: Add 'currentUser' to props to receive user data
  currentUser: User | null;
}

const AggregationJobItem: React.FC<{ job: AggregationJob }> = ({ job }) => {
    const statusInfo = {
        Done: {
            classes: 'bg-light-success/10 text-light-success dark:bg-dark-success/10 dark:text-dark-success',
            Icon: CheckCircleIcon
        },
        Running: {
            classes: 'bg-light-info/10 text-light-info dark:bg-dark-info/10 dark:text-dark-info',
            Icon: (props: React.SVGProps<SVGSVGElement>) => <ClockIcon {...props} className="animate-spin" />
        },
        Queued: {
            classes: 'bg-light-warning/10 text-light-warning dark:bg-dark-warning/10 dark:text-dark-warning',
            Icon: ClockIcon
        },
        Failed: {
            classes: 'bg-light-error/10 text-light-error dark:bg-dark-error/10 dark:text-dark-error',
            Icon: XCircleIcon
        },
    };
    const { classes, Icon } = statusInfo[job.status];
    return (
        <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary p-4 rounded-lg border border-light-border dark:border-dark-border flex justify-between items-center">
            <div>
                <p className="font-semibold text-light-text-primary dark:text-dark-text-primary">{job.name}</p>
                <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary">Base: {job.baseModel} | Created: {new Date(job.createdAt).toLocaleDateString()}</p>
            </div>
            <div className={`flex-shrink-0 text-xs font-medium px-2.5 py-1 rounded-full flex items-center gap-1.5 ${classes}`}>
                <Icon className="w-4 h-4" />
                <span>{job.status}</span>
            </div>
        </div>
    );
}

const ProfilePage: React.FC<ProfilePageProps> = ({ navigateTo, addToast, models, addModel, currentUser }) => {
  const [activeTab, setActiveTab] = useState('My Models');
  
  const [isForkModalOpen, setIsForkModalOpen] = useState(false);
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState<AIModel | null>(null);
  
  const myModels = useMemo(() => models.filter(m => m.author === 'Jane Doe' || m.author === 'SynthAI Labs'), [models]);
  const myAggregations = useMemo(() => AGGREGATION_JOBS_DATA.slice(0, 2), []); // Mock
  const favoriteModels = useMemo(() => models.filter(m => m.isFavorite), [models]);

  const TABS = ['My Models', 'My Aggregations', 'Favorites', 'Settings'];

  const handleForkClick = (model: AIModel) => {
    setSelectedModel(model);
    setIsForkModalOpen(true);
  };
  
  const handleUpgradeClick = (modelName: string) => {
    setSelectedModel({name: modelName} as AIModel);
    setIsUpgradeModalOpen(true);
  };

  const confirmFork = () => {
    if (!selectedModel) return;
    const newFork: AIModel = {
        ...selectedModel,
        id: Date.now().toString(),
        name: `${selectedModel.name} Fork`,
        author: 'Jane Doe',
        votes: 0,
        forks: 0,
        downloads: 0,
        status: 'Verified'
    };
    addModel(newFork);
    addToast(`Successfully forked '${selectedModel.name}'!`, 'success');
    setIsForkModalOpen(false);
    navigateTo('modelDetails', newFork.id);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'My Models':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myModels.length > 0 ? myModels.map(model => <ModelCard key={model.id} model={model} navigateTo={navigateTo} onFork={handleForkClick} onUpgrade={handleUpgradeClick} />) : <p className="text-light-text-secondary dark:text-dark-text-secondary">Your forked and uploaded models will appear here.</p>}
          </div>
        );
      case 'My Aggregations':
        return (
            <div className="space-y-4">
                {myAggregations.map(job => <AggregationJobItem key={job.id} job={job} />)}
            </div>
        );
      case 'Favorites':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favoriteModels.map(model => <ModelCard key={model.id} model={model} navigateTo={navigateTo} onFork={handleForkClick} onUpgrade={handleUpgradeClick} />)}
          </div>
        );
      case 'Settings':
        return (
            <div className="bg-light-bg-secondary dark:bg-dark-bg-secondary border border-light-border dark:border-dark-border rounded-lg p-6 max-w-2xl">
                <h3 className="text-xl font-semibold text-light-text-primary dark:text-dark-text-primary">Account Settings</h3>
                <p className="text-light-text-secondary dark:text-dark-text-secondary mt-1 mb-6">Manage your profile, billing, and account data.</p>
                <div className="space-y-4">
                    <button className="w-full text-left bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-3 px-4 rounded-lg transition-colors">Edit Profile</button>
                    <button onClick={() => navigateTo('pricing')} className="w-full text-left bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-3 px-4 rounded-lg transition-colors">Manage Billing & Plan</button>
                    <button className="w-full text-left bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-3 px-4 rounded-lg transition-colors">Export Account Data</button>
                     <div className="border-t border-light-error/30 dark:border-dark-error/30 pt-4">
                        <button className="w-full bg-light-error/10 hover:bg-light-error/20 text-light-error dark:bg-dark-error/10 dark:hover:bg-dark-error/20 dark:text-dark-error font-medium py-3 px-4 rounded-lg transition-colors">Delete Account</button>
                        <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary mt-2 text-center">This action is permanent and cannot be undone.</p>
                    </div>
                </div>
            </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto">
      {/* User Info Header */}
      <div className="flex flex-col sm:flex-row items-center gap-6 mb-10">
        <img className="h-24 w-24 rounded-full object-cover ring-4 ring-light-border dark:ring-dark-border" src="https://picsum.photos/seed/user/100/100" alt="User profile" />
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-3xl font-bold text-light-text-primary dark:text-dark-text-primary">{currentUser?.name || 'User'}</h2>
            <span className="bg-light-accent-secondary/10 dark:bg-dark-accent-secondary/10 text-light-accent-secondary dark:text-dark-accent-secondary text-sm font-medium px-3 py-1 rounded-full">Pro+ Plan</span>
          </div>
          <p className="text-light-text-secondary dark:text-dark-text-secondary">{currentUser?.email || 'user@example.com'}</p>
        </div>
      </div>

      {/* Quota Meters */}
      <div className="mb-10">
        <h3 className="text-xl font-semibold text-light-text-primary dark:text-dark-text-primary mb-4">Monthly Usage</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {USER_QUOTAS_DATA.map(quota => (
            <QuotaMeter key={quota.name} quota={quota} />
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-6 border-b border-light-border dark:border-dark-border">
        <nav className="-mb-px flex space-x-8" aria-label="Tabs">
          {TABS.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`${
                activeTab === tab
                  ? 'border-light-accent-primary dark:border-dark-accent-primary text-light-accent-primary dark:text-dark-accent-primary'
                  : 'border-transparent text-light-text-secondary dark:text-dark-text-secondary hover:text-light-text-primary dark:hover:text-dark-text-primary hover:border-light-text-secondary dark:hover:border-dark-text-secondary'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors`}
            >
              {tab}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div>
        {renderTabContent()}
      </div>

      {/* Fork Modal */}
      <Modal isOpen={isForkModalOpen} onClose={() => setIsForkModalOpen(false)} title={`Fork '${selectedModel?.name}'`}>
          <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
              You are about to create a new fork of this model. This will create a new, linked version in your profile that you can modify.
          </p>
          <div className="flex justify-end gap-3">
              <button onClick={() => setIsForkModalOpen(false)} className="bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-4 rounded-lg text-sm">Cancel</button>
              <button onClick={confirmFork} className="bg-light-accent-primary hover:bg-light-accent-primary-hover dark:bg-dark-accent-primary dark:hover:bg-dark-accent-primary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-4 rounded-lg text-sm">Confirm Fork</button>
          </div>
      </Modal>

      {/* Upgrade Modal */}
      <Modal isOpen={isUpgradeModalOpen} onClose={() => setIsUpgradeModalOpen(false)} title="Upgrade Required">
          <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
              The model <span className="font-bold text-light-text-primary dark:text-dark-text-primary">{selectedModel?.name}</span> is only available to users on a Pro plan or higher.
          </p>
          <div className="flex justify-end gap-3">
              <button onClick={() => setIsUpgradeModalOpen(false)} className="bg-light-bg dark:bg-dark-bg hover:bg-light-border dark:hover:bg-dark-border text-light-text-primary dark:text-dark-text-primary font-medium py-2 px-4 rounded-lg text-sm">Maybe Later</button>
              <button onClick={() => navigateTo('pricing')} className="bg-light-accent-secondary hover:bg-light-accent-secondary-hover dark:bg-dark-accent-secondary dark:hover:bg-dark-accent-secondary-hover text-light-accent-text dark:text-dark-accent-text font-medium py-2 px-4 rounded-lg text-sm">View Plans</button>
          </div>
      </Modal>
    </div>
  );
};

export default ProfilePage;
